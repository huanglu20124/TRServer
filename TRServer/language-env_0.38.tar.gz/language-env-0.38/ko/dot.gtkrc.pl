# s comment -*-coding: euc-kr;-*-
Setting for GTK+ Applications
END
Setting for GTK+ Applications
END
print <<"EOF";
style "user-font"
{
  fontset="-adobe-helvetica-medium-r-normal--12-120-75-75-*-*-iso8859-1,-*-$HFONT-medium-r-normal--12-120-75-75-*-120-ksc5601.1987-0"
}
widget_class "*" style "user-font"

EOF
