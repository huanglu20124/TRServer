# s comment -*-coding: euc-kr;-*-
Setting fot IceWM WindowManager.
END
Setting fot IceWM WindowManager.
END
print <<"EOF";
TitleFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
MenuFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
StatusFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
QuickSwitchFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
NormalButtonFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
ActiveButtonFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
NormalTaskBarFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
ActiveTaskBarFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
MinimizedWindowFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
ListBoxFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
ToolTipFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
ClockFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
ApmFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
LabelFontName="-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"
TimeFormat="%h%e�� %A %H:%M:%S"
DateFormat="%Y�� %h %e�� %A %H�� %M�� %S��(%Z)"

EOF
