! s comment -*-coding: euc-kr;-*-
Setting for some programs in X Window System.
END
Setting for some programs in X Window System.
END
print <<"EOF";
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! �̸ƽ��� ���ҽ��� �����ϴ� �κ��Դϴ�.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Emacs.Font:*-fontset-$HFONT
Emacs.Fontset-0:-*-*-medium-r-normal--14-*-*-*-*-*-fontset-$HFONT, \
	ascii:-*-fixed-medium-r-*--14-*-75-75-*-70-iso8859-1, \
	korean-ksc5601:-*-$HFONT-medium-r-normal--14-140-75-75-*-140-ksc5601.1987-0
emacs*geometry:80x26
emacs*Background:white
emacs*Foreground:black
emacs*pointerColor:black
emacs*cursorColor:blue
emacs*menubar*background:#cecedc
emacs*menubar*foreground:black


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! ������ ȯ���� �����ϴ� �κ��Դϴ�.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Hanterm*title: �ѱ��͹̳�
Hanterm*iconName: �ѱ��͹̳�
Hanterm*nowChatScroll: true
Hanterm*hangulKeyboard: $HKBD
Hanterm*escHangulToggle: true

! Ű ���ε� �� �ٸ��콺 ����
Hanterm*VT100.Translations: #override\\n\\
	<KeyPress>	Hangul:			toggle-hangul()\\n\\
	<KeyPress>	Hangul_Hanja:	hanja-input()\\n\\
	<KeyPress>	BackSpace:		string("")\\n\\
	<KeyPress>	Delete:			string("")\\n\\
	<Btn4Down>:					scroll-back(5,line) \\n\\
	<Btn5Down>:					scroll-forw(5,line)\\n

! ���� ��Ʈ ����
Hanterm*Font: -*-fixed-medium-r-normal--14-*-75-75-*-70-iso8859-1
Hanterm*boldFont: -*-fixed-medium-r-normal--14-*-75-75-*-70-iso8859-1
Hanterm*hangulFont: -*-$HFONT-medium-r-normal--14-140-75-75-*-140-ksc5601.1987-0
Hanterm*SimpleMenu*fontSet: -*-helvetica-medium-r-normal--12-120-75-75-*-*-iso8859-1,-*-$HFONT-medium-r-normal--12-120-75-75-*-*-ksc5601.1987-0
Hanterm*fontMenu.Label: �۲� ����
Hanterm*fontMenu*fontdefault*Label: �⺻ �۲�
Hanterm*fontMenu*font1*Label: $HFONT 12����Ʈ
Hanterm*fontList1: -*-fixed-medium-r-normal--*-*-75-75-*-60-iso8859-1,-*-$HFONT-medium-r-normal--12-120-75-75-*-120-ksc5601.1987-0
Hanterm*fontMenu*font2*Label: $HFONT 14����Ʈ
Hanterm*fontList2: -*-fixed-medium-r-normal--*-*-75-75-*-70-iso8859-1,-*-$HFONT-medium-r-normal--14-140-75-75-*-140-ksc5601.1987-0
Hanterm*fontMenu*font3*Label: $HFONT 16����Ʈ
Hanterm*fontList3: -*-fixed-medium-r-normal--*-*-75-75-*-80-iso8859-1,-*-$HFONT-medium-r-normal--16-160-75-75-*-160-ksc5601.1987-0
Hanterm*fontMenu*font4*Label: $HFONT 20����Ʈ
Hanterm*fontList4: -*-fixed-medium-r-normal--*-*-75-75-*-100-iso8859-1,-*-$HFONT-medium-r-normal--20-200-75-75-*-200-ksc5601.1987-0
Hanterm*fontMenu*font5*Label: $HFONT 24����Ʈ
Hanterm*fontList5: -*-fixed-medium-r-normal--*-*-75-75-*-120-iso8859-1,-*-$HFONT-medium-r-normal--24-240-75-75-*-240-ksc5601.1987-0
Hanterm*fontMenu*font6*Label: �ʹ��� ���� �۲�
Hanterm*fontList6: nil2,nil2
Hanterm*IconFont:      nil2
Hanterm*fontMenu*fontescape*Label: Escape Sequence
Hanterm*fontMenu*fontsel*Label: ���콺�� ���õ� �۲�

! ������ ������ �ʹ� ��ο� ���� �Ʒ��� �κ��� �ּ��� ���켼��.
!Hanterm*VT100*color0: #000000
!Hanterm*VT100*color1: #ff0000
!Hanterm*VT100*color2: #00ee00
!Hanterm*VT100*color3: #eeff00
!Hanterm*VT100*color4: #0000ff
!Hanterm*VT100*color5: #ff88ff
!Hanterm*VT100*color6: #008888
!Hanterm*VT100*color7: #f0f0f0
!Hanterm*VT100*color8: #e0e0e0
!Hanterm*VT100*color9: #dd4444
!Hanterm*VT100*color10: #44ff44
!Hanterm*VT100*color11: #ffff88
!Hanterm*VT100*color12: #aaccff
!Hanterm*VT100*color13: #ff88ff
!Hanterm*VT100*color14: #88ffff
!Hanterm*VT100*color15: #ffffff
Hanterm*VT100*colorBD: white
Hanterm*VT100*colorUL: white
Hanterm*background: black
Hanterm*foreground: #e0e0e0
Hanterm*vt100*cursorColor: cyan
Hanterm*SimpleMenu*background: #cecedc
Hanterm*SimpleMenu*foreground: black

! ��ũ�ѹ� ����
Hanterm*Scrollbar*width: 10
Hanterm*Scrollbar*background: #8888aa
Hanterm*shadowWidth: 2
Hanterm*highlightThickness: 0
Hanterm*topShadowContrast: 20
Hanterm*bottomShadowContrash: 55



!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! �ݽ��������� ���ҽ��� �����ϴ� �κ��Դϴ�.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Netscape*foreground: black
Netscape*background: #ACAABD
Netscape*selectForeground: #000000
Netscape*selectBackground: #888888
Netscape*documentFonts.EUC-KR*psname: Munhwa-Regular-KSC-EUC-H
Netscape*documentFonts.EUC-KR*pscode: euc-kr
Netscape*documentFonts.EUC-KR*pswidth: 1000
Netscape*documentFonts.EUC-KR*psascent: 1150
Netscape*globalNonTextTranslations: #override\\n\\
	Shift<Btn4Down>: LineUp()\\n\\
	Shift<Btn5Down>: LineDown()\\n\\
	None<Btn4Down>: LineUp()LineUp()LineUp()LineUp()LineUp()LineUp()\\n\\
	None<Btn5Down>: LineDown()LineDown()LineDown()LineDown()LineDown()LineDown()\\n\\
	Alt<Btn4Down>: xfeDoCommand(forward)\\n\\
	Alt<Btn5Down>: xfeDoCommand(back)\\n

EOF
