; s comment -*-coding: euc-kr;-*-
Setting fot Sawfish WindowManager.
END
Setting fot Sawfish WindowManager.
END
print <<"EOF";
(setq fonts-are-fontsets t)
(setq default-font
(get-font "-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"))
(setq ugly-cycle-iconified-font
(get-font "-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"))
(setq ugly-cycle-current-font
(get-font "-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"))
(setq ugly-cycle-font
(get-font "-*-helvetica-medium-r-normal--12-*-*-*-p-*-iso8859-1,-*-$HFONT-medium-r-normal--*-120-*-*-*-*-ksc5601.1987-0"))

EOF

