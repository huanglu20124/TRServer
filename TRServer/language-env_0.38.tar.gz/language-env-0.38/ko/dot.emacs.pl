; s comment -*-coding: euc-kr;-*-
GNU Emacs setting.
END
GNU Emacs setting.
END
print <<"EOF";
;;;##############################################################
;;; �ѱ��� ����� ���� ����
;;;##############################################################

(set-language-environment "Korean")   
(set-keyboard-coding-system 'euc-kr)
(setq default-korean-keyboard "$HKBD")

;; For use of `emacs -nw' in Hanterm
(if (null window-system)
    (progn (set-terminal-coding-system 'euc-kr)
           (define-key encoded-kbd-mode-map [27] nil)))


;;;##############################################################
;;; ��Ʈ �� â ũ�� ����
;;;##############################################################

(custom-set-faces '(italic ((t (:bold t :italic nil))))
                  '(bold-italic ((t (:bold t :italic nil)))))

(if (eq window-system 'x)
    (progn
     (create-fontset-from-fontset-spec
      "-*-fixed-medium-r-normal--14-*-75-75-*-70-fontset-$HFONT,
      ascii:-*-fixed-medium-r-normal--14-*-75-75-*-70-iso8859-1,
      korean-ksc5601:-*-$HFONT-medium-r-normal--14-140-75-75-*-140-ksc5601*-*" '(medium))
     (create-fontset-from-fontset-spec
      "-*-fixed-bold-r-normal--14-*-75-75-*-70-fontset-$HFONT,
      ascii:-*-fixed-bold-r-normal--14-*-75-75-*-70-iso8859-1,
      korean-ksc5601:-*-$HFONT-bold-r-normal--14-140-75-75-*-140-ksc5601*-*" '(bold))

     (setq default-frame-alist
      (append '((font . "fontset-$HFONT")(width . 80)(height . 26)
                (background-color . "White")(foreground-color . "Black")
                (vertical-scroll-bars . right)) default-frame-alist))))


;;;##############################################################
;;; ���α׷��� ���
;;;##############################################################

(setq default-major-mode (quote text-mode))
(add-hook 'text-mode-hook (function (lambda ()(turn-on-auto-fill))))
(add-hook 'TeX-mode-hook (function (lambda ()(turn-on-auto-fill))))
(add-hook 'java-mode-hook (function (lambda ()
 (c-set-style "java")(turn-on-auto-fill))))
(add-hook 'c-mode-hook (function (lambda ()
 (c-set-style "stroustrup")(turn-on-auto-fill))))
(add-hook 'c++-mode-hook (function (lambda ()
 (c-set-style "stroustrup")(turn-on-auto-fill))))
(add-hook 'idl-mode-hook (function (lambda ()
 (c-set-style "stroustrup")(turn-on-auto-fill))))


;;;##############################################################
;;; ��Ÿ ����
;;;##############################################################

(icomplete-mode)
(partial-completion-mode 1)
(column-number-mode 1)
(auto-compression-mode 1)
(global-font-lock-mode 1) 
(setq font-lock-maximum-decoration t)
(setq font-lock-maximum-size nil)
(setq column-number-mode t)
(display-time)
(custom-set-variables '(next-line-add-newlines nil) '(fill-column 72))

EOF
