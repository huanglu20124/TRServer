; s comment -*-coding: euc-kr;-*-
XEmacs21 setting.
END
XEmacs21 setting.
END
print <<"EOF";
;;;##############################################################
;;; �ѱ��� ����� ���� ����
;;;##############################################################

(set-language-environment "Korean")
(set-keyboard-coding-system 'euc-kr)
(setq default-korean-keyboard "$HKBD")
(global-set-key [hangul] 'toggle-input-method)
(setq input-method-verbose-flag nil input-method-highlight-flag nil)
(when (and enable-multibyte-characters window-system)
 (set-face-font 'default '
  ("-*-fixed-medium-r-normal--14-*-75-75-*-70-iso8859-1") 'global)
 (set-face-font 'default '
  ("-*-$HFONT-medium-r-normal--14-140-75-75-*-140-ksc5601.1987-0") 'global '
  (mule-fonts) 'prepend))

EOF
