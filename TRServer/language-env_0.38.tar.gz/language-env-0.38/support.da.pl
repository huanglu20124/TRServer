# !Dansk,Danish! -*-coding: iso-8859-1;-*-
#
# ---------------------------------------------------
# isNC()
# ---------------------------------------------------
sub isNC($$$)
{
	return 0;
}

# ---------------------------------------------------
# initialize()
# ---------------------------------------------------
sub initialize()
{
	&Sub::addlist("locales");
	if (&Sub::isinstalled("kdebase"))
		{&Sub::addlist("kde-i18n-da");}
	if (&Sub::isinstalled("aspell"))
		{&Sub::addlist("aspell-da");}
	if (&Sub::isinstalled("ispell"))
		{&Sub::addlist("idanish");}

	@locales = glob("/usr/lib/locale/da*");

# The locale package does not currently supply da_DK@euro
#	$Sub::ISO885915 = &Sub::yesno(
#			"Vil du bruge ISO-8859-15 (med euro-tegnet) ?",
#			"Vil du bruge ISO-8859-15 (med euro-tegnet) ?");

	if ($Sub::ISO885915) {
		$Sub::LOCALE = "da_DK\@euro";
		$Sub::ENCODING = "ISO-8859-15";
		$Lang::need_locale = "da_DK\@euro(da_DK\@euro!ISO-8859-15)";
		foreach $i ("xfonts-base", "xfonts-100dpi", "xfonts-75dpi") {
			if (&Sub::isinstalled($i)) {
				&Sub::addlist($i . "-transcoded");
			}
		}
	} else {
		$Sub::LOCALE = "da_DK";
		$Sub::ENCODING = "ISO-8859-1";
		$Lang::need_locale = "da_DK(da_DK!ISO-8859-1)";
	}
	return 0;
}

# ---------------------------------------------------
# sourceset2displayset()
# ---------------------------------------------------
sub sourceset2displayset ($)
{
	return $_[0];
}

# ---------------------------------------------------
# analcode()
# ---------------------------------------------------
sub analcode($)
{
	return 0;
}

# ---------------------------------------------------
# convcode()
# ---------------------------------------------------
sub convcode($$)
{
	return $_[0];
}


# ---------------------------------------------------
# messages
# ---------------------------------------------------

%messages = (

# msgid
  "\nPush [Enter] key to End.\n" =>
# msgstr (in ASCII)
  "\nTryk [Enter] for at afslutte programmet.\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "\nTryk [Enter] for at afslutte programmet.\n" ,

# msgid
  "Now obtaining package list...\n" =>
# msgstr (in ASCII)
  "Nu hentes pakkelisten...\n" ,

# msgid
  "Do setting? " =>
# msgstr (in ASCII)
  "Gennemfoer aendringer? \000" .
# msgstr (in native character set: for example ISO-8859-1)
  "Gennemf�r �ndringer? " ,

# msgid
  "Setting is not done.\n" =>
# msgstr (in ASCII)
  "Indstilling ikke gennemfoert.\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "Indstilling ikke gennemfoert.\n" ,

# msgid
  "Do setting...\n" =>
# msgstr (in ASCII)
  "Gennemfoer indstilling...\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "Gennemf�r indstilling...\n" ,

# msgid
  "Cannot read \"%s\".\n" =>
# msgstr (in ASCII)
  "Kan ikke laese \"%s\".\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "Kan ikke l�se \"%s\".\n" ,

# msgid
  "Making a new file \"%s\"...\n" =>
# msgstr (in ASCII)
  "Opretter ny fil \"%s\"...\n" ,

# msgid
  "Cannot open \"%s\".\n" =>
# msgstr (in ASCII)
  "Kan ikke aabne \"%s\".\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "Kan ikke �bne \"%s\".\n" ,

# msgid
  "Cannot write to \"%s\".\n" =>
# msgstr (in ASCII)
  "Kan ikke skrive til \"%s\".\n" ,

# msgid
  "Cannot lock \"%s\".\n" =>
# msgstr (in ASCII)
  "Kan ikke laase \"%s\".\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "Kan ikke l�se \"%s\".\n" ,

# msgid
  "Cannot close \"%s\".\n" =>
# msgstr (in ASCII)
  "Kan ikke lukke \"%s\".\n" ,

# msgid
  "Install the following packages.\n" =>
# msgstr (in ASCII)
  "Installer foelgende pakker:\n\000".
# msgstr (in native character set: for example ISO-8859-1)
  "Install�r f�lgende pakker:\n",

# msgid
  "   Setting is now done.  To activate these settings,\n".
  "logout and login.\n".
  "   Read each dotfile and confirm the modification.\n".
  "If you don't like the setting, modify directly or\n".
  "add overriding setting after 'language-env end' line.\n".
  "   Read /usr/share/doc/language-env/README.* for detail.\n" =>
# msgstr (in ASCII)
  "   Nu er opsaetningen udfoert. Den bliver aktiveret naeste gang, du\n".
  "logger paa.\n".
  "   Du kan laese hver enkelt skjult punktum-fil for at tjekke aendringerne.\n".
  "Hvis du ikke synes om indstillingerne, kan du aendre dem direkte eller\n".
  "tilfoeje en linje, der overtrumfer indstillingerne efter linjen\n".
  "'language-env'.\n\000".
  "   Laes /usr/share/doc/language-env/README.* for flere oplysninger.\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "   Nu er ops�tningen udf�rt. De bliver aktiveret n�ste gang, du logger\n".
  "p�.\n".
  "   Du kan l�se hver enkelt skjult punktum-fil for at tjekke �ndringerne.\n".
  "Hvis du ikke synes om indstillingerne, kan du �ndre dem direkte eller\n".
  "tilf�je en linje, der overtrumfer indstillingerne efter linjen\n".
  "'language-env'.\n".
  "   L�s /usr/share/doc/language-env/README.* for flere oplysninger.\n" ,

# msgid
  "Usage: set-language-env [options]\n".
  "  -l language : Specify language (otherwise choose from menu)\n".
  "  -h          : This help message\n".
  "  -v          : 'verbose mode'\n".
  "  -s          : Display list of supported languages and exit\n".
  "  -r          : Remove all settings\n".
  "  -N          : Never fork another set-language-env (for internal use)\n".
  "  -c          : Don't use native character set (for internal use)\n".
  "  -C          : Use native character set (for internal use)\n".
  "  -E          : Setting for /etc/skel directory (root user only)\n" =>
# msgstr (in ASCII)
  "Brug: set-language-env [tilvalg]\n".
  "  -l sprog    : Angiv sprog (ellers vaelg det fra menuen)\n".
  "  -h          : Denne hjaelpetekst\n".
  "  -v          : Detaljerede beskeder\n".
  "  -s          : Vis listen over understoettede sprog og afslut\n".
  "  -r          : Fjern alle indstillinger\n".
  "  -N          : Koer ikke nye instanser af set-language-env (til internt brug)\n".
  "  -c          : Brug ikke sprogets tegnsaet (til internt brug)\n".
  "  -C          : Brug sprogets tegnsaet (til internt brug)\n".
  "  -E          : Indstillinger for kataloget /etc/skel (kun root-brugeren)\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "Brug: set-language-env [tilvalg]\n".
  "  -l sprog    : Angiv sprog (ellers vaelg det fra menuen)\n".
  "  -h          : Denne hjaelpetekst\n".
  "  -v          : Detaljerede beskeder\n".
  "  -s          : Vis listen over understoettede sprog og afslut\n".
  "  -r          : Fjern alle indstillinger\n".
  "  -N          : Koer ikke nye instanser af set-language-env (til internt brug)\n".
  "  -c          : Brug ikke sprogets tegnsaet (til internt brug)\n".
  "  -C          : Brug sprogets tegnsaet (til internt brug)\n".
  "  -E          : Indstillinger for kataloget /etc/skel (kun root-brugeren)\n" ,

# msgid
  "Install the following locales.\n" =>
# msgstr1 (ASCII)
  "Installer foelgende lokaliseringer.\n\000".
# msgstr2 (in Native Character Set)
  "Install�r f�lgende lokaliseringer.\n",

# msgid
  "(Edit /etc/locale.gen and invoke locale-gen)\n" =>
# msgstr1 (ASCII)
  "(Rediger /etc/locale.gen og koer locale-gen)\n\000".
# msgstr2 (in Native Character Set)
  "(Redig�r /etc/locale.gen og k�r locale-gen)\n",

# msgid
"" =>
# msgstr1 (ASCII)
"\000".
# msgstr2 (in Native Character Set)
""

);

# ---------------------------------------------------
# yes and no
# ---------------------------------------------------
$yes_upper = "J";
$yes_lower = "j";
$no_upper = "N";
$no_lower = "n";

# ---------------------------------------------------
# This variable shows the needed locale.  This is
# introduced since language-env 0.12 because locales
# package stopped to supply precompiled locale data
# since locales 2.2-1.
#
# The check is done by whether the directory of
# /usr/lib/locales/$needlocale exists or not.
#
# Multiple locales can be specified with delimiter
# of space code.
# ---------------------------------------------------
#
# This variable is set by initialize().
# $need_locale = 'da_DK da_DK@euro';
# $need_locale = 'da_DK';
