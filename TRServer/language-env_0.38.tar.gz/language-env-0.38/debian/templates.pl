Template: language-env/installation_is_insufficient
Type: note
Description: Only installing this package doesn't work
 This package does not affect the configuration of your system during
 installation.  You need to login as an ordinary (non-root) user and
 invoke the "set-language-env" command.
Description-pl: Samo zainstalowanie tego pakietu nie wystarcza
 Ten pakiet podczas instalacji nie zmienia konfiguracji Twojego systemu.
 Nale�y zalogowa� si� jako zwyk�y u�ytkownik (nie root) i uruchomi� polecenie
 "set-language-env".
