# !Thai! -*-coding: tis-620;-*-
#
# ---------------------------------------------------
# isNC()
# ---------------------------------------------------
sub isNC($$$)
{
	my ($THIS, $OPT, $OPT_N, $TERM);
	$THIS = $_[0];
	$OPT = $_[1];
	$OPT_N = $_[2];
	$TERM = $ENV{COLORTERM};

	if ($TERM eq 'xiterm') {return 1;}
	if ($ENV{DISPLAY} ne '' && -x "/usr/bin/txiterm" && !$OPT_N) {
		exec("txiterm -e $THIS -N -C $OPT");
	}
	return 0;
}

# ---------------------------------------------------
# initialize()
# ---------------------------------------------------
sub initialize()
{
	&Sub::addlist("locales");
	&Sub::addlist("xiterm+thai");
	if (&Sub::isinstalled("xserver-.*")) {
		&Sub::addlist("nonlock");
		&Sub::addlist("xfonts-thai-nectec");
		&Sub::addlist("xfonts-thai-manop");
		&Sub::addlist("xfonts-thai-vor");
	}
	return 0;
}

# ---------------------------------------------------
# sourceset2displayset()
# ---------------------------------------------------
sub sourceset2displayset ($)
{
	return $_[0];
}

# ---------------------------------------------------
# analcode()
# ---------------------------------------------------
sub analcode($)
{
	return 0;
}

# ---------------------------------------------------
# convcode()
# ---------------------------------------------------
sub convcode($$)
{
	return $_[0];
}


# ---------------------------------------------------
# messages
# ---------------------------------------------------

%messages = (

# msgid
"\nPush [Enter] key to End.\n" =>
# msgstr (in ASCII)
"\nPush [Enter] key to End.\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
"\n������ [Enter] ���ͨ���÷ӧҹ.\n" ,

"Now obtaining package list...\n" =>
"Now obtaining package list...\n\000" .
"���ѧ���� package list...\n" ,

"Do setting? " =>
"Do setting? \n\000" .
"��ͧ��õ�駤������? " ,

"Setting is not done.\n" =>
"Setting is not done.\n\000" .
"�������ö��駤���� \n" ,

"Do setting...\n" =>
"Do setting...\n\000" .
"��駤��...\n" ,

"Cannot read \"%s\".\n" =>
"Cannot read \"%s\".\n\000" .
"�������ö��ҹ \"%s\".\n" ,

"Making a new file \"%s\"...\n" =>
"Making a new file \"%s\"...\n\000" .
"���ѧ��¹��� \"%s\"...\n" ,

"Cannot open \"%s\".\n" =>
"Cannot open \"%s\".\n\000" .
"�������ö�Դ��� \"%s\"\n" ,

"Cannot write to \"%s\".\n" =>
"Cannot write to \"%s\".\n\000" .
"�������ö��¹��� \"%s\"\n" ,

"Cannot lock \"%s\".\n" =>
"Cannot lock \"%s\".\n\000" .
"�������ö��ͤ��� \"%s\"\n" ,

"Cannot close \"%s\".\n" =>
"Cannot close \"%s\".\n\000" .
"�������ö�Դ��� \"%s\"\n" ,

"Install the following packages.\n" =>
"Install the following packages.\n\000" .
"�Դ��� package ���仹��\n" ,

"   Setting is now done.  To activate these settings,\n".
"logout and login.\n".
"   Read each dotfile and confirm the modification.\n".
"If you don't like the setting, modify directly or\n".
"add overriding setting after 'language-env end' line.\n".
"   Read /usr/share/doc/language-env/README.* for detail.\n" =>
"   Setting is now done.  To activate these settings,\n".
"logout and login.\n".
"   Read each dotfile and confirm the modification.\n".
"If you don't like the setting, modify directly or\n".
"add overriding setting after 'language-env end' line.\n".
"   Read /usr/share/doc/language-env/README.* for detail.\n\000" .
"��õԴ���������� logout ���� login �����������ҵԴ�������\n".
"   Read each dotfile and confirm the modification.\n".
"If you don't like the setting, modify directly or\n".
"add overriding setting after 'language-env end' line.\n".
"   Read /usr/share/doc/language-env/README.* for detail.\n" ,

"Usage: set-language-env [options]\n".
"  -l language : Specify language (otherwise choose from menu)\n".
"  -h          : This help message\n".
"  -v          : 'verbose mode'\n".
"  -s          : Display list of supported languages and exit\n".
"  -r          : Remove all settings\n".
"  -N          : Never fork another set-language-env (for internal use)\n".
"  -c          : Don't use native character set (for internal use)\n".
"  -C          : Use native character set (for internal use)\n".
"  -E          : Setting for /etc/skel directory (root user only)\n" =>
"Usage: set-language-env [options]\n".
"  -l language : Specify language (otherwise choose from menu)\n".
"  -h          : This help message\n".
"  -v          : 'verbose mode'\n".
"  -s          : Display list of supported languages and exit\n".
"  -r          : Remove all settings\n".
"  -N          : Never fork another set-language-env (for internal use)\n".
"  -c          : Don't use native character set (for internal use)\n".
"  -C          : Use native character set (for internal use)\n".
"  -E          : Setting for /etc/skel directory (root user only)\n",

# msgid
"Install the following locales.\n" =>
# msgstr1 (ASCII)
"Install the following locales.\n\000".
# msgstr2 (in Native Character Set)
"Install the following locales.\n" ,

# msgid
"(Edit /etc/locale.gen and invoke locale-gen)\n" =>
# msgstr1 (ASCII)
"(Edit /etc/locale.gen and invoke locale-gen)\n\000".
# msgstr2 (in Native Character Set)
"(Edit /etc/locale.gen and invoke locale-gen)\n" ,

# msgid
"" =>
# msgstr1 (ASCII)
"\000".
# msgstr2 (in Native Character Set)
""
 
);

# ---------------------------------------------------
# yes and no
# ---------------------------------------------------
$yes_upper = "Y";
$yes_lower = "y";
$no_upper = "N";
$no_lower = "n";

# ---------------------------------------------------
# This variable shows the needed locale.  This is
# introduced since language-env 0.12 because locales
# package stopped to supply precompiled locale data
# since locales 2.2-1.
#
# The check is done by whether the directory of
# /usr/lib/locales/$needlocale exists or not.
#
# Multiple locales can be specified with delimiter
# of space code.
# ---------------------------------------------------
$need_locale = "th_TH(th_TH!TIS-620)";
