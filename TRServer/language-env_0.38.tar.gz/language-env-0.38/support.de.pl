# !Deutsch,German! -*-coding: iso-8859-1;-*-
#
# ---------------------------------------------------
# isNC()
# ---------------------------------------------------
sub isNC($$$)
{
	return 0;
}

# ---------------------------------------------------
# initialize()
# ---------------------------------------------------
sub initialize()
{
	&Sub::addlist("locales");
	&Sub::addlist("manpages-de");
	&Sub::addlist("doc-linux-de");
	if (&Sub::isinstalled("gs-aladdin"))
		{&Sub::addlist("gs-aladdin-manual-de");}
	if (&Sub::isinstalled("manpages-dev"))
		{&Sub::addlist("manpages-de-dev");}


	@locales = glob("/usr/lib/locale/de*");
	@countries = (
		'DE!Germany',
		'AT!Austria',
		'BE!Belgium',
		'CH!Switzerland',
		'LU!Luxembourg');
	$num = 0; $default = 0;
	foreach $country (@countries) {
		@c = split(/!/, $country);
		$pattern = "de_" . $c[0];
		if (grep($_ =~ /$pattern/, @locales) && $default == 0) {
			$default = $num;
		}
		print $num+1,". ",$c[1],"\n";
		$num ++;
	}
	print $num+1,". others\n";

	$territory = &Sub::select(
		"Which country do you live in?\n" . $choices,
		"Which country do you live in?\n" . $choices,
		$num+1, $default+1);

	if ($territory == $num+1) {
		$Sub::COUNTRY = &Sub::ask(
			"Input ISO3166 two-character code of your country ",
			"Input ISO3166 two-character code of your country ");
	} else {
		@c = split(/!/,$countries[$territory - 1]);
		$Sub::COUNTRY = $c[0];
	}

	$Sub::ISO885915 = &Sub::yesno(
			"Do you want to use ISO-8859-15 (euro sign) ?",
			"Do you want to use ISO-8859-15 (euro sign) ?");

	if ($Sub::ISO885915) {
		$Sub::LOCALE = "de_" . $Sub::COUNTRY . "\@euro";
		$Sub::ENCODING = "ISO-8859-15";
		$Lang::need_locale = "$Sub::LOCALE($Sub::LOCALE!ISO-8859-15)";
		foreach $i ("xfonts-base", "xfonts-100dpi", "xfonts-75dpi") {
			if (&Sub::isinstalled($i)) {
				&Sub::addlist($i . "-transcoded");
			}
		}
	} else {
		$Sub::LOCALE = "de_" . $Sub::COUNTRY;
		$Sub::ENCODING = "ISO-8859-1";
		$Lang::need_locale = "$Sub::LOCALE($Sub::LOCALE!ISO-8859-1)";
	}
	return 0;
}

# ---------------------------------------------------
# sourceset2displayset()
# ---------------------------------------------------
sub sourceset2displayset ($)
{
	return $_[0];
}

# ---------------------------------------------------
# analcode()
# ---------------------------------------------------
sub analcode($)
{
	return 0;
}

# ---------------------------------------------------
# convcode()
# ---------------------------------------------------
sub convcode($$)
{
	return $_[0];
}


# ---------------------------------------------------
# messages
# ---------------------------------------------------

%messages = (

# msgid
  "\nPush [Enter] key to End.\n" =>
# msgstr (in ASCII)
  "\nDruecken Sie [Enter] um das Programm zu beenden.\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "\nDr�cken Sie [Enter] um das Programm zu beenden.\n" ,

# msgid
  "Now obtaining package list...\n" =>
# msgstr (in ASCII)
  "Erstelle Paketliste...\n" ,

# msgid
  "Do setting? " =>
# msgstr (in ASCII)
  "Diese Einstellung durchfuehren? \000" .
# msgstr (in native character set: for example ISO-8859-1)
  "Diese Einstellung durchf�hren? " ,

# msgid
  "Setting is not done.\n" =>
# msgstr (in ASCII)
  "Einstellung ist nicht erfolgt.\n" ,

# msgid
  "Do setting...\n" =>
# msgstr (in ASCII)
  "Einstellung erfolgt...\n" ,

# msgid
  "Cannot read \"%s\".\n" =>
# msgstr (in ASCII)
  "Cannot read \"%s\".\n" ,

# msgid
  "Making a new file \"%s\"...\n" =>
# msgstr (in ASCII)
  "Making a new file \"%s\"...\n" ,

# msgid
  "Cannot open \"%s\".\n" =>
# msgstr (in ASCII)
  "Kann \"%s\" nicht oeffnen.\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "Kann \"%s\" nicht �ffnen.\n" ,

# msgid
  "Cannot write to \"%s\".\n" =>
# msgstr (in ASCII)
  "Kann nicht in \"%s\" schreiben.\n" ,

# msgid
  "Cannot lock \"%s\".\n" =>
# msgstr (in ASCII)
  "Kann kein Lock erhalten auf \"%s\".\n" ,

# msgid
  "Cannot close \"%s\".\n" =>
# msgstr (in ASCII)
  "Kann \"%s\" nicht schliessen.\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "Kann \"%s\" nicht schlie�en.\n" ,

# msgid
  "Install the following packages.\n" =>
# msgstr (in ASCII)
  "Folgende Pakete werden ergaenzend zur Installation vorgeschlagen:\n\000".
# msgstr (in native character set: for example ISO-8859-1)
  "Folgende Pakete werden erg�nzend zur Installation vorgeschlagen:\n" ,

# msgid
  "   Setting is now done.  To activate these settings,\n".
  "logout and login.\n".
  "   Read each dotfile and confirm the modification.\n".
  "If you don't like the setting, modify directly or\n".
  "add overriding setting after 'language-env end' line.\n".
  "   Read /usr/share/doc/language-env/README.* for detail.\n" =>
# msgstr (in ASCII)
  "   Einstellung sind erfolgt.  Sie werden beim naechsten\n".
  "Login wirksam.\n".
  "   Sie koennen die geaenderten Einstellungs-Dateien lesen und die\n".
  "Aenderungen ueberpruefen. Falls notwendig, koennen Sie die hinzugefueg-\n".
  "ten Zeilen direkt abaendern oder hinter der Zeile 'language-env end'\n".
  "Einstellungen anfuegen, die so dann vor den vorhergehenden Einstel-\n".
  "lungen Vorrang haben.\n".
  "   Lesen Sie /usr/share/doc/language-env/README.* fuer naehere Angaben.\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
  "   Einstellung sind erfolgt.  Sie werden beim n�chsten\n".
  "Login wirksam.\n".
  "   Sie k�nnen die ge�nderten Einstellungs-Dateien lesen und die\n".
  "�nderungen �berpr�fen. Falls notwendig, k�nnen Sie die hinzugef�g-\n".
  "ten Zeilen direkt ab�ndern oder hinter der Zeile 'language-env end'\n".
  "Einstellungen anf�gen, die so dann vor den vorhergehenden Einstel-\n".
  "lungen Vorrang haben.\n".
  "   Lesen Sie /usr/share/doc/language-env/README.* f�r n�here Angaben.\n" ,

# msgid
  "Usage: set-language-env [options]\n".
  "  -l language : Specify language (otherwise choose from menu)\n".
  "  -h          : This help message\n".
  "  -v          : 'verbose mode'\n".
  "  -s          : Display list of supported languages and exit\n".
  "  -r          : Remove all settings\n".
  "  -N          : Never fork another set-language-env (for internal use)\n".
  "  -c          : Don't use native character set (for internal use)\n".
  "  -C          : Use native character set (for internal use)\n".
  "  -E          : Setting for /etc/skel directory (root user only)\n" =>
# msgstr (in ASCII)
  "Benutzung: set-language-env [Optionen]\n".
  "  -l Sprache  : Sprache angeben (sonst wird ein Menue angezeigt)\n".
  "  -h          : dieser Hilfe-Text\n".
  "  -v          : 'verbose mode'(das Programm kommentiert was es tut)\n".
  "  -s          : Zeigt nur eine Liste der unterstuetzten Sprachen an\n".
  "  -r          : Entfernt alle Einstellungen\n".
  "  -N          : Never fork another set-language-env (for internal use)\n".
  "  -c          : Don't use native character set (for internal use)\n".
  "  -C          : Use native character set (for internal use)\n".
  "  -E          : Setting for /etc/skel directory (root user only)\n\000".
# msgstr (in native character set: for example ISO-8859-1)
  "Benutzung: set-language-env [Optionen]\n".
  "  -l Sprache  : Sprache angeben (sonst wird ein Men� angezeigt)\n".
  "  -h          : dieser Hilfe-Text\n".
  "  -v          : 'verbose mode'(das Programm kommentiert was es tut)\n".
  "  -s          : Zeigt nur eine Liste der unterst�tzten Sprachen an\n".
  "  -r          : Entfernt alle Einstellungen\n".
  "  -N          : Never fork another set-language-env (for internal use)\n".
  "  -c          : Don't use native character set (for internal use)\n".
  "  -C          : Use native character set (for internal use)\n".
  "  -E          : Setting for /etc/skel directory (root user only)\n",

# msgid
  "Install the following locales.\n" =>
# msgstr1 (ASCII)
  "Install the following locales.\n\000".
# msgstr2 (in Native Character Set)
  "Install the following locales.\n" ,

# msgid
  "(Edit /etc/locale.gen and invoke locale-gen)\n" =>
# msgstr1 (ASCII)
  "(Edit /etc/locale.gen and invoke locale-gen)\n\000".
# msgstr2 (in Native Character Set)
  "(Edit /etc/locale.gen and invoke locale-gen)\n" ,

# msgid
"" =>
# msgstr1 (ASCII)
"\000".
# msgstr2 (in Native Character Set)
""

);

# ---------------------------------------------------
# yes and no
# ---------------------------------------------------
$yes_upper = "J";
$yes_lower = "j";
$no_upper = "N";
$no_lower = "n";

# ---------------------------------------------------
# This variable shows the needed locale.  This is
# introduced since language-env 0.12 because locales
# package stopped to supply precompiled locale data
# since locales 2.2-1.
#
# The check is done by whether the directory of
# /usr/lib/locales/$needlocale exists or not.
#
# Multiple locales can be specified with delimiter
# of space code.
# ---------------------------------------------------
#
# This variable is set by initialize().
# $need_locale = 'de_DE de_DE@euro';
