#   comment -*-coding: iso-8859-1;-*-
Indstiller tegnaettet i pine
END
Indstiller tegns�ttet i pine
END
print "# Character set to be used.\n";
if ($ISO885915) {
print "character-set=ISO-8859-15\n";
} else {
print "character-set=ISO-8859-1\n";
}
