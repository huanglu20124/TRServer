;   comment -*-coding: iso-8859-1;-*-
Danske indstillinger for Emacs
END
Danske indstillinger for Emacs
END
print <<'EOF';
; $Id: emacs,v 1.4 1998/02/20 18:35:26 leutloff Exp leutloff $

;;--- support european keys ------------------------------- 

; `standard-display-european' is semi-obsolete and conflicts
; with multibyte characters. `set-language-environment' is
; a substitute.
; (standard-display-european t)
(set-input-mode (car (current-input-mode))
        (nth 1 (current-input-mode))
        0) 
	
; don't use non-ascii (i.e. Danish oslash) as word delimiter
EOF
if ($ENCODING eq 'ISO-8859-1') {
	print
		"(if (>= emacs-major-version 20)\n" .
		"    (set-language-environment \"Latin-1\")\n" .
		"    (require 'iso-syntax))\n";
} else {
	print
		"(if (>= emacs-major-version 21)\n" .
		"    (set-language-environment \"Latin-9\")\n" .
		"    (if (>= emacs-major-version 20)\n" .
		"        (set-language-environment \"Latin-1\")\n" .
		"        (require 'iso-syntax)))\n";
}
print <<'EOF';
(require 'disp-table)
EOF
