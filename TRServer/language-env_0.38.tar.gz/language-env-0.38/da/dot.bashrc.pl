# s comment -*-coding: iso-8859-1;-*-
Aktiverer understoettelse for dansk paa kommandolinjen og i de
fleste programmer. Udfoeres hver gang, du logger paa.
END
Aktiverer underst�ttelse for dansk p� kommandolinjen og i de
fleste programmer. Udf�res hver gang, du logger p�.
END
print <<"EOF";
# settings for danish speaking users

LANG=$LOCALE
export LANG


LESSCHARSET=latin1
export LESSCHARSET

#LC_MESSAGES=$LOCALE
#LC_CTYPE=$LOCALE
#export LC_MESSAGES LC_CTYPE

if [ -d /usr/X11R6/lib/X11/nls ]; then
    XNLSPATH=/usr/X11R6/lib/X11/nls
    export XNLSPATH
fi

export MM_CHARSET=$ENCODING
EOF



