! s comment -*-coding: iso-8859-1;-*-
Saetter standardsproget for stavekontrollen aspell til dansk
END
S�tter standardsproget for stavekontrollen aspell til dansk
END

print <<"EOF";
lang danish
EOF


