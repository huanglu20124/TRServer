;   comment -*-coding: iso-8859-1;-*-
Deutsche Einstellungen fuer Emacs
END
Deutsche Einstellungen f�r Emacs
END
print <<'EOF';
; $Id: emacs,v 1.4 1998/02/20 18:35:26 leutloff Exp leutloff $

;;--- support european keys ------------------------------- 
(set-input-mode  (car (current-input-mode))
		 (nth 1 (current-input-mode))
		 0)
; `standard-display-european' is semi-obsolete and conflicts
; with multibyte characters. `set-language-environment' is
; a substitute.
; (standard-display-european t)

; don't use non-ascii (i.e. german umlauts) as word delimiter
EOF
if ($ENCODING eq 'ISO-8859-1') {
	print
		"(if (>= emacs-major-version 20)\n" .
		"    (set-language-environment \"Latin-1\")\n" .
		"    (require 'iso-syntax))\n";
} else {
	print
		"(if (>= emacs-major-version 21)\n" .
		"    (progn\n" .
		"      (set-language-environment \"Latin-9\")\n" .
		"      (setq selection-coding-system 'compound-text-with-extensions)\n" .
		"    )\n" .
		"    (if (>= emacs-major-version 20)\n" .
		"        (set-language-environment \"Latin-1\")\n" .
		"        (require 'iso-syntax)))\n";
}
print <<'EOF';
(require 'disp-table)

;;--- redefine some keys ----------------------------------
;(global-set-key [backspace] 'backward-delete-char-untabify)
; the following line should not break delete char during incremental
; search - has this other disadvantages?
(global-set-key "\177" 'backward-delete-char-untabify)
(global-set-key [delete] 'delete-char)
(global-set-key [home] 'beginning-of-line)
(global-set-key [end] 'end-of-line)
;(global-set-key [C-home] 'beginning-of-buffer)
;(global-set-key [C-end] 'end-of-buffer)
; entries needed by XEmacs:
(global-set-key [(control home)] 'beginning-of-buffer)
(global-set-key [(control end)] 'end-of-buffer)
;;--- Names for calendar command -------------------------
(defvar calendar-day-name-array
  ["Son" "Mon" "Die" "Mit" "Don" "Fre" "Sam"])
(defvar calendar-month-name-array
  ["Januar" "Februar" "M�rz" "April" "Mai" "Juni" 
   "Juli" "August" "September" "Oktober" "November" "Dezember"])
EOF
