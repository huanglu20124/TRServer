# s comment -*-coding: iso-8859-1;-*-
Aktiviert die vorhandene Unterstuetzung fuer Deutsch auf der
Kommandozeile und in den meisten anderen Programmen.
Wird beim Start von bash ausgefuehrt.
END
Aktiviert die vorhandene Unterst�tzung f�r Deutsch auf der
Kommandozeile und in den meisten anderen Programmen.
Wird beim Start von bash ausgef�hrt.
END
print <<"EOF";
# settings for german speaking users

LANG=$LOCALE
export LANG

#LC_MESSAGES=$LOCALE
#LC_CTYPE=$LOCALE
#export LC_MESSAGES LC_CTYPE

if [ -d /usr/X11R6/lib/X11/nls ]; then
    XNLSPATH=/usr/X11R6/lib/X11/nls
    export XNLSPATH
fi

export MM_CHARSET=$ENCODING
EOF
