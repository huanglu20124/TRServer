! s comment -*-coding: iso-8859-1;-*-
Active les preferences pour les utilisateurs francais dans
les applications sous X Window.
END
Active les pr�f�rences pour les utilisateurs fran�ais dans
les applications sous X Window.
END
if ($ISO885915) {
	print <<'EOF';
! ISO-8859-15 (Latin-9) fonts for XTerm
XTerm*Font: -misc-fixed-medium-r-normal--13-*-*-*-*-*-iso8859-15
XTerm*Font2: -misc-fixed-medium-r-normal--8-*-*-*-*-*-iso8859-15
XTerm*Font3: -misc-fixed-medium-r-normal--10-*-*-*-*-*-iso8859-15
XTerm*Font4: -misc-fixed-medium-r-normal--13-*-*-*-*-*-iso8859-15
XTerm*Font5: -misc-fixed-medium-r-normal--18-*-*-*-*-*-iso8859-15
XTerm*Font6: -misc-fixed-medium-r-normal--20-*-*-*-*-*-iso8859-15
! ISO-8859-15 (Latin-9) fonts for Rxvt
Rxvt*font: -misc-fixed-medium-r-normal--13-*-*-*-*-*-iso8859-15
Rxvt*font2: -misc-fixed-medium-r-normal--8-*-*-*-*-*-iso8859-15
Rxvt*font3: -misc-fixed-medium-r-normal--10-*-*-*-*-*-iso8859-15
Rxvt*font4: -misc-fixed-medium-r-normal--13-*-*-*-*-*-iso8859-15
Rxvt*font5: -misc-fixed-medium-r-normal--18-*-*-*-*-*-iso8859-15
Rxvt*font6: -misc-fixed-medium-r-normal--20-*-*-*-*-*-iso8859-15
! ISO-8859-15 fonts for many softwares
*font:-*-*-medium-r-normal--14-*-*-*-c-*-iso8859-15
EOF
} else {
	print <<'EOF';
! xterm is UTF-8 mode.
!XTerm*Utf8: 1
! font 5 have doublewidth fonts.
! Since iso10646 is a superset of iso8859-1, these fonts can be
! used for ISO-8859-1 mode, too.
XTerm*Font: -misc-fixed-medium-r-normal--13-*-*-*-*-*-iso10646-1
XTerm*Font2: -misc-fixed-medium-r-normal--8-*-*-*-*-*-iso10646-1
XTerm*Font3: -misc-fixed-medium-r-normal--10-*-*-*-*-*-iso10646-1
XTerm*Font4: -misc-fixed-medium-r-normal--13-*-*-*-*-*-iso10646-1
XTerm*Font5: -misc-fixed-medium-r-normal--18-*-*-*-*-*-iso10646-1
XTerm*Font6: -misc-fixed-medium-r-normal--20-*-*-*-*-*-iso10646-1
EOF
}
