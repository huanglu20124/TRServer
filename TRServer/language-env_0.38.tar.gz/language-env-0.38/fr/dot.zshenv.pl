# s comment -*-coding: iso-8859-1;-*-
Active les preferences pour les utilisateurs francais dans
la console et les autres applications.
Appele au demarrage de zsh.
END
Active les pr�f�rences pour les utilisateurs fran�ais dans
la console et les autres applications.
Appel� au d�marrage de zsh.
END
print <<"EOF";
# settings for french speaking users

# set LANG
export LANG=$LOCALE
EOF
