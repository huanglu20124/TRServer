#   comment -*-coding: iso-8859-1;-*-
Active les preferences pour les utilisateurs francais dans
la console et les autres applications.
Execute lorsque ash ou ksh est appele au login.
END
Active les pr�f�rences pour les utilisateurs fran�ais dans
la console et les autres applications.
Ex�cut� lorsque ash ou ksh est appel� au login.
END
print <<"EOF";
# settings for french speaking users

# set LANG
LANG=$LOCALE
export LANG
EOF
