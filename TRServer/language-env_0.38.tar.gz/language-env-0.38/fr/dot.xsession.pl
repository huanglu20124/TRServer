#xs comment -*-coding: iso-8859-1;-*-
Active les preferences pour les utilisateurs francais sous
X Window. Execute lorsque xdm, wdm ou xinit est utilise.
END
Active les pr�f�rences pour les utilisateurs fran�ais sous
X Window. Ex�cut� lorsque xdm, wdm ou xinit est utilis�.
END
print <<"EOF";
# set LANG
LANG=$LOCALE
export LANG
EOF

if ($DOTFILECONTENTS2 eq "") {
	print <<'EOF';

if [ -x "$WINDOW_MANAGER" ]; then
  realstartup=$WINDOW_MANAGER
elif [ -x /usr/bin/x-session-manager ]; then
  realstartup=x-session-manager
elif [ -x /usr/bin/x-window-manager ]; then
  realstartup=x-window-manager
elif [ -x /usr/bin/x-terminal-emulator ]; then
  realstartup=x-terminal-emulator
fi
exec $realstartup
EOF
}
