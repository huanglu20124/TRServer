;   comment -*-coding: iso-8859-1;-*-
emacs settings.
END
emacs settings.
END
if ($ENCODING eq 'ISO-8859-1') {
	print
		"(if (>= emacs-major-version 20)\n" .
		"    (set-language-environment \"Latin-1\")\n" .
		"    (require 'iso-syntax))\n";
} else {
	print
		"(if (>= emacs-major-version 21)\n" .
		"    (progn\n" .
		"      (set-language-environment \"Latin-9\")\n" .
		"      (setq selection-coding-system 'compound-text-with-extensions)\n" .
		"    )\n" .
		"    (if (>= emacs-major-version 20)\n" .
		"        (set-language-environment \"Latin-1\")\n" .
		"        (require 'iso-syntax)))\n";
}
print <<'EOF';
;; Names for calendar command.
;; These should be derived from nl_langinfo() by emacs
;;
(defvar calendar-day-name-array
  ["dim" "lun" "mar" "mer" "jeu" "ven" "sam"])
(defvar calendar-month-name-array
  ["janvier" "f�vrier" "mars" "avril" "mai" "juin" 
   "juillet" "ao�t" "septembre" "octobre" "novembre" "d�cembre"])
EOF
