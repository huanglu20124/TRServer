# s comment -*-coding: iso-8859-1;-*-
Active les preferences pour les utilisateurs francais dans
la console et les autres applications.
Execute lorsque bash est appele au login.
END
Active les pr�f�rences pour les utilisateurs fran�ais dans
la console et les autres applications.
Ex�cut� lorsque bash est appel� au login.
END
print <<"EOF";
# settings for french speaking users

# set LANG
export LANG=$LOCALE
EOF
