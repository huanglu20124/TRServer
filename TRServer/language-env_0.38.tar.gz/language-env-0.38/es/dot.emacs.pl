;   comment -*-coding: iso-8859-1;-*-
settings for emacs
END
settings for emacs
END
print <<'EOF';
;-*-emacs-lisp-*-
;;/etc/emacs/site-start.d/50user-es.el
;

;;--- soportar teclado europeo ------------------------------- 
(set-input-mode  (car (current-input-mode))
		 (nth 1 (current-input-mode))
		 0)
; `standard-display-european' is semi-obsolete and conflicts
; with multibyte characters. `set-language-environment' is
; a substitute.
; (standard-display-european t)

; no usar caracteres no-ascii (como acentos) como final de palabra
EOF
if ($ENCODING eq 'ISO-8859-1') {
	print
		"(if (>= emacs-major-version 20)\n" .
		"    (set-language-environment \"Latin-1\")\n" .
		"    (require 'iso-syntax))\n";
} else {
	print
		"(if (>= emacs-major-version 21)\n" .
		"    (progn\n" .
		"      (set-language-environment \"Latin-9\")\n" .
		"      (setq selection-coding-system 'compound-text-with-extensions)\n" .
		"    )\n" .
		"    (if (>= emacs-major-version 20)\n" .
		"        (set-language-environment \"Latin-1\")\n" .
		"        (require 'iso-syntax)))\n";
}
print <<'EOF';
(require 'disp-table)

;;--- redefinir algunas teclas ----------------------------------
;(global-set-key [backspace] 'backward-delete-char-untabify)
; la siguiente l�nea no deber�a ropmer el caracter de borrado
; en b�squedas incrementales - tiene esto otras desventajas?
(global-set-key "\177" 'backward-delete-char-untabify)
(global-set-key [delete] 'delete-char)
(global-set-key [home] 'beginning-of-line)
(global-set-key [end] 'end-of-line)
;(global-set-key [C-home] 'beginning-of-buffer)
;(global-set-key [C-end] 'end-of-buffer)

; Otras varias (gracias a Jose Manuel Moya)
(defvar cursor-map-2 (make-keymap) "for ESC-[")
(fset 'Cursor-Map-2 cursor-map-2)
(define-key esc-map "[" 'Cursor-Map-2)

(define-key esc-map "[A" 'previous-line)
(define-key esc-map "[B" 'next-line)
(define-key esc-map "[C" 'forward-char)
(define-key esc-map "[D" 'backward-char)
(define-key esc-map "[H" 'beginning-of-line)
(define-key esc-map "[Y" 'end-of-line)
(define-key esc-map "[5^" 'scroll-down)
(define-key esc-map "[6^" 'scroll-up)
(define-key esc-map "[[A" 'help-for-help)
(define-key esc-map "[[B" 'byte-compile-file)
(define-key esc-map "[[C" 'isearch-forward)
(define-key esc-map "[[D" 'query-replace-regexp)
(define-key esc-map "[[E" 'eval-defun)
(define-key esc-map "[[F" 'eval-current-buffer)
(define-key esc-map "[[G" 'buffer-menu)
(define-key esc-map "[[H" 'global-set-key)
(define-key esc-map "[[I" 'save-buffer)
(define-key esc-map "[[J" 'save-buffers-kill-emacs)
(define-key esc-map "[2^" 'set-mark-command)
(define-key esc-map "[3^" 'delete-char)

; entradas necesarias para XEmacs:
(global-set-key [(control home)] 'beginning-of-buffer)
(global-set-key [(control end)] 'end-of-buffer)
EOF
