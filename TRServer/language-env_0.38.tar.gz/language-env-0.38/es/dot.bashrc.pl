# s comment -*-coding: iso-8859-1;-*-
Executed when bash is invoked.
END
Executed when bash is invoked.
END
print <<"EOF";
# valores para usuarios hispanoparlantes
# settings for spanish speaking users
#

LANG=$LOCALE
export LANG

#LC_MESSAGES=$LOCALE
#LC_CTYPE=$LOCALE
#export LC_MESSAGES LC_CTYPE

if [ -d /usr/X11R6/lib/X11/nls ]; then
    XNLSPATH=/usr/X11R6/lib/X11/nls
    export XNLSPATH
fi


# Sacado del Spanish-COMO
set meta-flag on                # conservar bit 8 en entrada de teclado
set output-meta on      # conservar bit 8 en salida por terminal
set convert-meta off    # no convertir secuencias de escape
set horizontal-scroll-mode on
LESSCHARSET=latin1

# Obtenido de http://members.xoom.com/sromero/linux/castell.html
export MM_CHARSET=$ENCODING    # para usar latin1 en los mails
EOF
