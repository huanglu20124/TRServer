! s comment -*-coding: euc-jp;-*-
X Window System DE UGOKU program NO SETTEI DESU.
END
X Window System ��ư���ץ�����������Ǥ���
END

print <<'EOF';
!---------------------------------------------------------
! XIM ������
!---------------------------------------------------------
! XIM �����С���̾�����������
EOF


if ($IM_DEFAULT eq "Canna") {
	print "#define XIM kinput2\n";
} elsif ($IM_DEFAULT eq "Wnn") {
	print "#define XIM kinput2\n";
} elsif ($IM_DEFAULT eq "SKK") {
	print "#define XIM skkinput\n";
} 


print <<'EOF';
!Kinput2*conversionStartKeys: Shift<Key>space \n\
!	Ctrl<Key>o \n\
!	Ctrl<Key>backslash \n\
!	Alt<Key>Zenkaku_Hankaku
Kinput2*conversionStartKeys: Shift<Key>space
skkinput*conversionStartKey: Shift<Key>space

!---------------------------------------------------------
! emacs ������
!---------------------------------------------------------
! emacs20 �Υե��������
Emacs.Fontset-0: -*-fixed-medium-r-normal--14-*-*-*-*-*-fontset-14,\
  korean-ksc5601:-*-mincho-medium-r-normal--16-*-*-*-*-*-ksc*-*,\
  chinese-gb2312:-*-fang*-medium-r-normal--16-*-*-*-*-*-gb2312*-*
Emacs.Fontset-1: -*-fixed-medium-r-normal--12-*-*-*-*-*-fontset-12
Emacs.Fontset-2: -*-fixed-medium-r-normal--24-*-*-*-*-*-fontset-24
Emacs.Fontset-3: -*-fixed-medium-r-normal--16-*-*-*-*-*-fontset-16,\
  korean-ksc5601:-*-mincho-medium-r-normal--16-*-*-*-*-*-ksc*-*,\
  chinese-gb2312:-*-fang*-medium-r-normal--16-*-*-*-*-*-gb2312*-*
Emacs.Font: fontset-14

! xemacs21 �Υե�������� (���ޤꤦ�ޤ�ư���ʤ�����)
XEmacs.default.attributeFont: -*-fixed-medium-r-normal--16-*-*-*-*-*-*-*
!XEmacs.default.attributeFont: -*-fixed-medium-r-normal--14-*-*-*-*-*-*-*

! emacs ���� kinput2 ����ư���ʤ��褦�ˡ�
Emacs*xnlLanguage: C
! xemacs21 �ξ�硣
XEmacs*xnlLanguage: C
!XEmacs*xnlLanguage: ja_JP.eucJP

!---------------------------------------------------------
! ����¾�Υ��ץꥱ������� (���ܸ��Ϣ)
!---------------------------------------------------------
*inputMethod: XIM
KTerm*VT100*KanjiMode: euc
KTerm*openIm: true
!KTerm*VT100.Translations: #override\
!	Ctrl<Key>o: begin-conversion(_JAPANESE_CONVERSION)\n\
!	~Meta <Key>BackSpace: string("\177")\n\
!	<Key>Delete: string("\033[3~")\n\
!	<Key>Home: string("\033OH")\n\
!	<Key>End: string("\033OF")
Xedit*international: true
Xedit*fontSet: a14,k14,r14,*
! xterm is UTF-8 mode.
!XTerm*Utf8: 1
! font 0 and font 5 can display Japanese.
! Since iso10646 is a superset of iso8859-1, these fonts can be
! used for non-utf8 mode, too.
XTerm*Font: -misc-fixed-medium-r-semicondensed--13-*-*-*-*-*-iso10646-1
XTerm*Font2: -misc-fixed-medium-r-normal--8-*-*-*-*-*-iso10646-1
XTerm*Font3: -misc-fixed-medium-r-normal--10-*-*-*-*-*-iso10646-1
XTerm*Font4: -misc-fixed-medium-r-normal--13-*-*-*-*-*-iso10646-1
XTerm*Font5: -misc-fixed-medium-r-normal--18-*-*-*-*-*-iso10646-1
XTerm*Font6: -misc-fixed-medium-r-normal--20-*-*-*-*-*-iso10646-1
EOF
if (!$EXTENDED) {return;}
print <<'EOF';
!---------------------------------------------------------
! ����¾�Υ��ץꥱ�������
!---------------------------------------------------------
KTerm*VT100*SaveLines: 1000
KTerm*VT100*ScrollBar: true
KTerm*allowSendEvents: true
XTerm*VT100*SaveLines: 1000
XTerm*VT100*ScrollBar: true
Rxvt*saveLines: 1000
EOF
