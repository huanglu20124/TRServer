# !Espanol,Spanish! -*-coding: iso-8859-1;-*-
#
# ---------------------------------------------------
# isNC()
# ---------------------------------------------------
sub isNC($$$)
{
	return 0;
}

# ---------------------------------------------------
# initialize()
# ---------------------------------------------------
sub initialize()
{
	&Sub::addlist("locales");
	&Sub::addlist("manpages-es");
	&Sub::addlist("manpages-es-extra");
	&Sub::addlist("doc-linux-es");
	&Sub::addlist("doc-debian-es");

	@locales = glob("/usr/lib/locale/es*");
	@countries = (
		'ES!Spain',
		'AR!Argentina',
		'BO!Bolivia',
		'CL!Chile',
		'CO!Colombia',
		'CR!Costa Rica',
		'DO!Dominican Republic',
		'EC!Ecuador',
		'GT!Guatemala',
		'HN!Honduras',
		'MX!Mexico',
		'NI!Nicaragua',
		'PA!Panama',
		'PE!Peru',
		'PR!Puerto Rico',
		'PY!Paraguay',
		'SV!El Salvador',
		'US!United States',
		'UY!Uruguay',
		'VE!Venezuela');
	$num = 0; $default = 0;
	foreach $country (@countries) {
		@c = split(/!/, $country);
		$pattern = "es_" . $c[0];
		if (grep($_ =~ /$pattern/, @locales) && $default == 0) {
			$default = $num;
		}
		print $num+1,". ",$c[1],"\n";
		$num ++;
	}
	print $num+1,". others\n";

	$territory = &Sub::select(
		"Which country do you live in?\n" . $choices,
		"Which country do you live in?\n" . $choices,
		$num+1, $default+1);

	if ($territory == $num+1) {
		$Sub::COUNTRY = &Sub::ask(
			"Input ISO3166 two-character code of your country ",
			"Input ISO3166 two-character code of your country ");
	} else {
		@c = split(/!/,$countries[$territory - 1]);
		$Sub::COUNTRY = $c[0];
	}

	if ($Sub::COUNTRY eq 'ES') {
		$Sub::ISO885915 = &Sub::yesno(
			"Do you want to use ISO-8859-15 (euro sign) ?",
			"Do you want to use ISO-8859-15 (euro sign) ?");
	} else {
		$Sub::ISO885915 = &Sub::noyes(
			"Do you want to use ISO-8859-15 (euro sign) ?",
			"Do you want to use ISO-8859-15 (euro sign) ?");
	}

	if ($Sub::ISO885915) {
		$Sub::LOCALE = "es_" . $Sub::COUNTRY . "\@euro";
		$Sub::ENCODING = "ISO-8859-15";
		$Lang::need_locale = "$Sub::LOCALE($Sub::LOCALE!ISO-8859-15)";
		foreach $i ("xfonts-base", "xfonts-100dpi", "xfonts-75dpi") {
			if (&Sub::isinstalled($i)) {
				&Sub::addlist($i . "-transcoded");
			}
		}
	} else {
		$Sub::LOCALE = "es_" . $Sub::COUNTRY;
		$Sub::ENCODING = "ISO-8859-1";
		$Lang::need_locale = "$Sub::LOCALE($Sub::LOCALE!ISO-8859-1)";
	}
	return 0;
}

# ---------------------------------------------------
# sourceset2displayset()
# ---------------------------------------------------
sub sourceset2displayset ($)
{
	return $_[0];
}

# ---------------------------------------------------
# analcode()
# ---------------------------------------------------
sub analcode($)
{
	return 0;
}

# ---------------------------------------------------
# convcode()
# ---------------------------------------------------
sub convcode($$)
{
	return $_[0];
}


# ---------------------------------------------------
# messages
# ---------------------------------------------------

%messages = (

# msgid
"\nPush [Enter] key to End.\n" =>
# msgstr (in ASCII)
"\nEmpuje la tecla de [Enter] al final.\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
"\nEmpuje la tecla de [Enter] al final.\n" ,

"Now obtaining package list...\n" =>
"Ahora obtencion de la lista del conjunto...\n\000" .
"Ahora obtenci�n de la lista del conjunto...\n" ,

"Do setting? " =>
"Configuracion? \000" .
"Configuraci�n? " ,

"Setting is not done.\n" =>
"La coniguraci�n no se hace.\n" ,

"Do setting...\n" =>
"Do setting...\n" ,

"Cannot read \"%s\".\n" =>
"Cannot read \"%s\".\n" ,

"Making a new file \"%s\"...\n" =>
"Making a new file \"%s\"...\n" ,

"Cannot open \"%s\".\n" =>
"No puede abrir \"%s\".\n" ,

"Cannot write to \"%s\".\n" =>
"No puede escribir al \"%s\".\n" ,

"Cannot lock \"%s\".\n" =>
"Cannot lock \"%s\".\n" ,

"Cannot close \"%s\".\n" =>
"Cannot close \"%s\".\n" ,

"Install the following packages.\n" =>
"Install the following packages.\n" ,

"   Setting is now done.  To activate these settings,\n".
"logout and login.\n".
"   Read each dotfile and confirm the modification.\n".
"If you don't like the setting, modify directly or\n".
"add overriding setting after 'language-env end' line.\n".
"   Read /usr/share/doc/language-env/README.* for detail.\n" =>
"   Se han hecho las configuraciones.  To activate these settings,\n".
"logout and login.\n".
"   Read each dotfile and confirm the modification.\n".
"If you don't like the setting, modify directly or\n".
"add overriding setting after 'language-env end' line.\n".
"   Lea /usr/share/doc/language-env/README.* para el detalle.\n" ,

"Usage: set-language-env [options]\n".
"  -l language : Specify language (otherwise choose from menu)\n".
"  -h          : This help message\n".
"  -v          : 'verbose mode'\n".
"  -s          : Display list of supported languages and exit\n".
"  -r          : Remove all settings\n".
"  -N          : Never fork another set-language-env (for internal use)\n".
"  -c          : Don't use native character set (for internal use)\n".
"  -C          : Use native character set (for internal use)\n".
"  -E          : Setting for /etc/skel directory (root user only)\n" =>
"Uso: set-language-env [opciones]\n".
"  -l lenguaje : Especifique el lenguaje (si no elija de menu)\n".
"  -h          : Este mensaje de la ayuda\n".
"  -v          : Prolijo modo\n".
"  -s          : Lista de la visualizacion utilizados de lenguajes y de la salida\n".
"  -r          : Quite todas las configuraciones\n" .
"  -N          : No invoque otro set-language-env (para interno el uso)\n".
"  -c          : Don't use native character set (for internal use)\n".
"  -C          : Use native character set (for internal use)\n".
"  -E          : Setting for /etc/skel directory (root user only)\n\000".
"Uso: set-language-env [opciones]\n".
"  -l lenguaje : Especifique el lenguaje (si no elija de men�)\n".
"  -h          : Este mensaje de la ayuda\n".
"  -v          : Prolijo modo\n".
"  -s          : Lista de la visualizaci�n utilizados de lenguajes y de la salida\n".
"  -r          : Quite todas las configuraciones\n".
"  -N          : No invoque otro set-language-env (para interno el uso)\n".
"  -c          : Don't use native character set (for internal use)\n".
"  -C          : Use native character set (for internal use)\n".
"  -E          : Setting for /etc/skel directory (root user only)\n",

# msgid
"Install the following locales.\n" =>
# msgstr1 (ASCII)
"Install the following locales.\n\000".
# msgstr2 (in Native Character Set)
"Install the following locales.\n" ,

# msgid
"(Edit /etc/locale.gen and invoke locale-gen)\n" =>
# msgstr1 (ASCII)
"(Edit /etc/locale.gen and invoke locale-gen)\n\000".
# msgstr2 (in Native Character Set)
"(Edit /etc/locale.gen and invoke locale-gen)\n" ,

# msgid
"" =>
# msgstr1 (ASCII)
"\000".
# msgstr2 (in Native Character Set)
""

);

# ---------------------------------------------------
# yes and no
# ---------------------------------------------------
$yes_upper = "S";
$yes_lower = "s";
$no_upper = "N";
$no_lower = "n";

# ---------------------------------------------------
# This variable shows the needed locale.  This is
# introduced since language-env 0.12 because locales
# package stopped to supply precompiled locale data
# since locales 2.2-1.
#
# The check is done by whether the directory of
# /usr/lib/locales/$needlocale exists or not.
#
# Multiple locales can be specified with delimiter
# of space code.
# ---------------------------------------------------
#
# This variable is set by initialize().
# $need_locale = 'es_ES es_ES@euro';

