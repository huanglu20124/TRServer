
print <<'EOF';
# Setup the Cyrillic
if test ${HOME}/.xcyrillic; then . ${HOME}/.xcyrillic; fi

# Check if the user suplies startup commands by him/herself
xsession=~/.xsession
if sed '1,/^. ---- language-env end/d' $xsession | grep -qs '^ *[^#]'; then
    exec sh -c  "sed '1,/^. ---- language-env end/d' $xsession | bash"
fi

# If he/she doesn't, then emulate the default action.

if [ -x /usr/bin/x-session-manager ]; then
    realstartup=x-session-manager
elif [ -x /usr/bin/x-window-manager ]; then
    realstartup=x-window-manager
elif [ -x /usr/bin/x-terminal-emulator ]; then
    realstartup=x-terminal-emulator
else
# Fatal error
    echo '~/.xsession: unable to start X session: no session managers,'
    echo '~/.xsession: no window managers, and no terminal emulators found.'
    echo '~/.xsession: Aborting.'
    exit 1
fi

if grep -qs ^use-ssh-agent /etc/X11/Xsession.options; then 
    if [ -x $sshagent -a -z "$SSH_AUTH_SOCK" -a -z "$SSH2_AUTH_SOCK" ]; then
	if [ -f /usr/bin/ssh-add1 ] \
		&& cmp -s /usr/bin/ssh-agent /usr/bin/ssh-agent2
	then
	    # use ssh-agent2's ssh-agent1 compatibility mode
	    realstartup="/usr/bin/ssh-agent -1 $realstartup"
	else
	    realstartup="/usr/bin/ssh-agent $realstartup"
	fi
    fi
fi

exec $realstartup
EOF
