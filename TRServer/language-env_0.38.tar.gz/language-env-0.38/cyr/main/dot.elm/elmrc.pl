print "# Character set to be used.\n";
if ($CYR_ENC eq "UTF-8") {
    print "CHARSET=utf-8\n";
}
if ($CYR_ENC eq "CP1251") {
    print "CHARSET=windows-1251\n";
}
if ($CYR_ENC eq "ISO8859-5") {
    print "CHARSET=iso-8859-5\n";
}
if ($CYR_ENC eq "KOI8-R") {
    print "CHARSET=koi8-r\n";
}
if ($CYR_ENC eq "KOI8-U") {
    print "CHARSET=koi8-u\n";
}
if ($CYR_ENC eq "ISO8859-2") {
    print "CHARSET=iso-8859-2\n";
}
