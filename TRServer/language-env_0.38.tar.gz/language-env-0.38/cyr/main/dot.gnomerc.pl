
print <<'EOF';
# Setup the language environment
if test ${HOME}/.xcyrillic; then . ${HOME}/.xcyrillic; fi
EOF




