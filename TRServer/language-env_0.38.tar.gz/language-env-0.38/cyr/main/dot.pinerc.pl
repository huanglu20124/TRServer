print "# Character set to be used.\n";
if ($CYR_ENC eq "UTF-8") {
    print "character-set=utf-8\n";
}
if ($CYR_ENC eq "CP1251") {
    print "character-set=windows-1251\n";
}
if ($CYR_ENC eq "ISO8859-5") {
    print "character-set=iso-8859-5\n";
}
if ($CYR_ENC eq "KOI8-R") {
    print "character-set=koi8-r\n";
}
if ($CYR_ENC eq "KOI8-U") {
    print "character-set=koi8-u\n";
}
if ($CYR_ENC eq "ISO8859-2") {
    print "character-set=iso-8859-2\n";
}
print "# Don't send mails quoted-printable\n";
print "enable-8bit-nntp-posting\n";
print "enable-8bit-esmtp-negotiation\n";
