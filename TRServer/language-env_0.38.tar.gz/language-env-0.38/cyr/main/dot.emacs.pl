print <<'EOF';
;; Some macros.
(defmacro GNUEmacs (&rest x)
  (list 'if (string-match "GNU Emacs 20" (version)) (cons 'progn x)))
(defmacro XEmacs (&rest x)
  (list 'if (string-match "XEmacs 21" (version)) (cons 'progn x)))

;; Setup Cyrillic
(set-input-mode (car (current-input-mode))
		(nth 1 (current-input-mode))
		0)
(standard-display-european 1)
(XEmacs
 (global-set-key [(iso-lock)]
		 '(lambda () (interactive) nil))
 (global-set-key [(iso-level2-latch)]
		 '(lambda () (interactive) nil))
 (global-set-key [(iso-level3-shift)]
		 '(lambda () (interactive) nil))
 (global-set-key [(iso-level3-latch)]
		 '(lambda () (interactive) nil))
 (global-set-key [(iso-group-latch)]
		 '(lambda () (interactive) nil))
 (global-set-key [(iso-next-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(iso-prev-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(iso-first-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(iso-last-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(control iso-lock)]
		 '(lambda () (interactive) nil))
 (global-set-key [(control iso-level2-latch)]
		 '(lambda () (interactive) nil))
 (global-set-key [(control iso-level3-shift)]
		 '(lambda () (interactive) nil))
 (global-set-key [(control iso-level3-latch)]
		 '(lambda () (interactive) nil))
 (global-set-key [(control iso-group-latch)]
		 '(lambda () (interactive) nil))
 (global-set-key [(control iso-next-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(control iso-prev-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(control iso-first-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(control iso-last-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(meta iso-lock)]
		 '(lambda () (interactive) nil))
 (global-set-key [(meta iso-level2-latch)]
		 '(lambda () (interactive) nil))
 (global-set-key [(meta iso-level3-shift)]
		 '(lambda () (interactive) nil))
 (global-set-key [(meta iso-level3-latch)]
		 '(lambda () (interactive) nil))
 (global-set-key [(meta iso-group-latch)]
		 '(lambda () (interactive) nil))
 (global-set-key [(meta iso-next-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(meta iso-prev-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(meta iso-first-group)]
		 '(lambda () (interactive) nil))
 (global-set-key [(meta iso-last-group)]
		 '(lambda () (interactive) nil))
EOF

if ($CYR_ENC eq "ISO8859-2") {
print <<'EOF';
 (global-set-key [(caron)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(breve)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(degree)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(ogonek)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(abovedot)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(doubleacute)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(diaeresis)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(cedilla)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(scaron)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Scaron)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(division)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(dstroke)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Dstroke)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(multiply)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(lstroke)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Lstroke)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(ccaron)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ccaron)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(cacute)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cacute)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(ssharp)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(section)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(zcaron)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Zcaron)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(currency)]
                 '(lambda () (interactive) (insert "�")))
EOF
}
if ($CYR_ENC eq "CP1251") {
print <<'EOF';
 (global-set-key [(brokenbar)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Byelorussian_SHORTU)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Byelorussian_shortu)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(copyright)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(currency)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_A)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_a)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_BE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_be)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_CHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_che)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_DE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_de)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_dzhe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_DZHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_E)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_e)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EF)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ef)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EL)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_el)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EM)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_em)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_en)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ER)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_er)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ES)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_es)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_GHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ghe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_HA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_HARDSIGN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_hardsign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_I)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_i)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_IE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ie)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_IO)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_io)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_JE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_je)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_KA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ka)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_lje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_LJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_nje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_NJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_O)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_o)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_PE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_pe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_sha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHCHA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_shcha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHORTI)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_shorti)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SOFTSIGN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_softsign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_TE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_te)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_TSE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_tse)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_U)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_u)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_VE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ve)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ya)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YERU)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_yeru)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YU)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_yu)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ZE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ze)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ZHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_zhe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(dagger)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(degree)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(doubledagger)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(doublelowquotemark)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(ellipsis)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(emdash)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(endash)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(EuroSign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(guillemotleft)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(guillemotright)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(leftdoublequotemark)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(leftsinglequotemark)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_dse)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_DSE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_gje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_GJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_kje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_KJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(mu)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(nobreakspace)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(notsign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(numerosign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(periodcentered)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(plusminus)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(registered)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(rightdoublequotemark)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(rightsinglequotemark)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(section)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Serbian_dje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Serbian_DJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Serbian_tshe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Serbian_TSHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(singlelowquotemark)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(trademark)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_GHEUP)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_gheup)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_I)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_i)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_IE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_ie)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_YI)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_yi)]
                 '(lambda () (interactive) (insert "�")))
EOF
}
if ($CYR_ENC eq "ISO8859-5") {
    print <<'EOF';
 (global-set-key [(brokenbar)]
                 '(lambda () (interactive) (insert "|")))
 (global-set-key [(Byelorussian_SHORTU)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Byelorussian_shortu)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(copyright)]
                 '(lambda () (interactive) (insert "C")))
 (global-set-key [(currency)]
                 '(lambda () (interactive) (insert "*")))
 (global-set-key [(Cyrillic_A)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_a)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_BE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_be)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_CHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_che)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_DE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_de)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_dzhe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_DZHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_E)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_e)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EF)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ef)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EL)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_el)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EM)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_em)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_en)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ER)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_er)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ES)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_es)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_GHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ghe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_HA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_HARDSIGN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_hardsign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_I)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_i)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_IE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ie)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_IO)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_io)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_JE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_je)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_KA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ka)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_lje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_LJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_nje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_NJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_O)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_o)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_PE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_pe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_sha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHCHA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_shcha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHORTI)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_shorti)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SOFTSIGN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_softsign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_TE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_te)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_TSE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_tse)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_U)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_u)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_VE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ve)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ya)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YERU)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_yeru)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YU)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_yu)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ZE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ze)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ZHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_zhe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(dagger)]
                 '(lambda () (interactive) (insert "+")))
 (global-set-key [(degree)]
                 '(lambda () (interactive) (insert "o")))
 (global-set-key [(doublelowquotemark)]
                 '(lambda () (interactive) (insert "\"")))
 (global-set-key [(ellipsis)]
                 '(lambda () (interactive) (insert ".")))
 (global-set-key [(emdash)]
                 '(lambda () (interactive) (insert "-")))
 (global-set-key [(endash)]
                 '(lambda () (interactive) (insert "-")))
 (global-set-key [(EuroSign)]
                 '(lambda () (interactive) (insert "E")))
 (global-set-key [(guillemotleft)]
                 '(lambda () (interactive) (insert "<")))
 (global-set-key [(guillemotright)]
                 '(lambda () (interactive) (insert ">")))
 (global-set-key [(leftdoublequotemark)]
                 '(lambda () (interactive) (insert "\"")))
 (global-set-key [(leftsinglequotemark)]
                 '(lambda () (interactive) (insert "\'")))
 (global-set-key [(Macedonia_dse)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_DSE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_gje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_GJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_kje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_KJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(mu)]
                 '(lambda () (interactive) (insert "u")))
 (global-set-key [(nobreakspace)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(notsign)]
                 '(lambda () (interactive) (insert "~")))
 (global-set-key [(numerosign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(registered)]
                 '(lambda () (interactive) (insert "R")))
 (global-set-key [(rightdoublequotemark)]
                 '(lambda () (interactive) (insert "\"")))
 (global-set-key [(rightsinglequotemark)]
                 '(lambda () (interactive) (insert "\'")))
 (global-set-key [(section)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Serbian_dje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Serbian_DJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Serbian_tshe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Serbian_TSHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(singlelowquotemark)]
                 '(lambda () (interactive) (insert "\'")))
 (global-set-key [(Ukrainian_GHEUP)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_gheup)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_I)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_i)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_IE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_ie)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_YI)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_yi)]
                 '(lambda () (interactive) (insert "�")))
EOF
}
if ($CYR_ENC eq "KOI8-R") {
    print <<'EOF';
 (global-set-key [(brokenbar)]
                 '(lambda () (interactive) (insert "|")))
 (global-set-key [(Byelorussian_SHORTU)]
                 '(lambda () (interactive) (insert "Y")))
 (global-set-key [(Byelorussian_shortu)]
                 '(lambda () (interactive) (insert "y")))
 (global-set-key [(copyright)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(currency)]
                 '(lambda () (interactive) (insert "*")))
 (global-set-key [(Cyrillic_A)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_a)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_BE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_be)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_CHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_che)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_DE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_de)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_dzhe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_DZHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_E)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_e)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EF)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ef)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EL)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_el)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EM)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_em)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_en)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ER)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_er)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ES)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_es)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_GHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ghe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_HA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_HARDSIGN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_hardsign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_I)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_i)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_IE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ie)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_IO)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_io)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_JE)]
                 '(lambda () (interactive) (insert "J")))
 (global-set-key [(Cyrillic_je)]
                 '(lambda () (interactive) (insert "j")))
 (global-set-key [(Cyrillic_KA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ka)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_lje)]
                 '(lambda () (interactive) (insert "l")))
 (global-set-key [(Cyrillic_LJE)]
                 '(lambda () (interactive) (insert "L")))
 (global-set-key [(Cyrillic_nje)]
                 '(lambda () (interactive) (insert "n")))
 (global-set-key [(Cyrillic_NJE)]
                 '(lambda () (interactive) (insert "N")))
 (global-set-key [(Cyrillic_O)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_o)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_PE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_pe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_sha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHCHA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_shcha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHORTI)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_shorti)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SOFTSIGN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_softsign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_TE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_te)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_TSE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_tse)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_U)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_u)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_VE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ve)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ya)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YERU)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_yeru)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YU)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_yu)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ZE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ze)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ZHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_zhe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(dagger)]
                 '(lambda () (interactive) (insert "+")))
 (global-set-key [(degree)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(doublelowquotemark)]
                 '(lambda () (interactive) (insert "\"")))
 (global-set-key [(ellipsis)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(emdash)]
                 '(lambda () (interactive) (insert "-")))
 (global-set-key [(endash)]
                 '(lambda () (interactive) (insert "-")))
 (global-set-key [(EuroSign)]
                 '(lambda () (interactive) (insert "E")))
 (global-set-key [(guillemotleft)]
                 '(lambda () (interactive) (insert "<")))
 (global-set-key [(guillemotright)]
                 '(lambda () (interactive) (insert ">")))
 (global-set-key [(leftdoublequotemark)]
                 '(lambda () (interactive) (insert "\"")))
 (global-set-key [(leftsinglequotemark)]
                 '(lambda () (interactive) (insert "\'")))
 (global-set-key [(Macedonia_dse)]
                 '(lambda () (interactive) (insert "s")))
 (global-set-key [(Macedonia_DSE)]
                 '(lambda () (interactive) (insert "S")))
 (global-set-key [(Macedonia_gje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_GJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_kje)]
                 '(lambda () (interactive) (insert "k")))
 (global-set-key [(Macedonia_KJE)]
                 '(lambda () (interactive) (insert "K")))
 (global-set-key [(mu)]
                 '(lambda () (interactive) (insert "u")))
 (global-set-key [(nobreakspace)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(notsign)]
                 '(lambda () (interactive) (insert "~")))
 (global-set-key [(numerosign)]
                 '(lambda () (interactive) (insert "N")))
 (global-set-key [(periodcentered)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(registered)]
                 '(lambda () (interactive) (insert "R")))
 (global-set-key [(rightdoublequotemark)]
                 '(lambda () (interactive) (insert "\"")))
 (global-set-key [(rightsinglequotemark)]
                 '(lambda () (interactive) (insert "\'")))
 (global-set-key [(section)]
                 '(lambda () (interactive) (insert "#")))
 (global-set-key [(Serbian_dje)]
                 '(lambda () (interactive) (insert "d")))
 (global-set-key [(Serbian_DJE)]
                 '(lambda () (interactive) (insert "D")))
 (global-set-key [(Serbian_tshe)]
                 '(lambda () (interactive) (insert "h")))
 (global-set-key [(Serbian_TSHE)]
                 '(lambda () (interactive) (insert "h")))
 (global-set-key [(singlelowquotemark)]
                 '(lambda () (interactive) (insert "\'")))
 (global-set-key [(Ukrainian_GHEUP)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_gheup)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_I)]
                 '(lambda () (interactive) (insert "I")))
 (global-set-key [(Ukrainian_i)]
                 '(lambda () (interactive) (insert "i")))
 (global-set-key [(Ukrainian_IE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_ie)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_YI)]
                 '(lambda () (interactive) (insert "I")))
 (global-set-key [(Ukrainian_yi)]
                 '(lambda () (interactive) (insert "i")))
EOF
}
if ($CYR_ENC eq "KOI8-U") {
    print <<'EOF';
 (global-set-key [(brokenbar)]
                 '(lambda () (interactive) (insert "|")))
 (global-set-key [(Byelorussian_SHORTU)]
                 '(lambda () (interactive) (insert "Y")))
 (global-set-key [(Byelorussian_shortu)]
                 '(lambda () (interactive) (insert "y")))
 (global-set-key [(copyright)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(currency)]
                 '(lambda () (interactive) (insert "*")))
 (global-set-key [(Cyrillic_A)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_a)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_BE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_be)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_CHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_che)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_DE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_de)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_dzhe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_DZHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_E)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_e)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EF)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ef)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EL)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_el)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EM)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_em)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_EN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_en)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ER)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_er)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ES)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_es)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_GHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ghe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_HA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_HARDSIGN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_hardsign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_I)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_i)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_IE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ie)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_IO)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_io)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_JE)]
                 '(lambda () (interactive) (insert "J")))
 (global-set-key [(Cyrillic_je)]
                 '(lambda () (interactive) (insert "j")))
 (global-set-key [(Cyrillic_KA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ka)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_lje)]
                 '(lambda () (interactive) (insert "l")))
 (global-set-key [(Cyrillic_LJE)]
                 '(lambda () (interactive) (insert "L")))
 (global-set-key [(Cyrillic_nje)]
                 '(lambda () (interactive) (insert "n")))
 (global-set-key [(Cyrillic_NJE)]
                 '(lambda () (interactive) (insert "N")))
 (global-set-key [(Cyrillic_O)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_o)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_PE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_pe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_sha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHCHA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_shcha)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SHORTI)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_shorti)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_SOFTSIGN)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_softsign)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_TE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_te)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_TSE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_tse)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_U)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_u)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_VE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ve)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YA)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ya)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YERU)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_yeru)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_YU)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_yu)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ZE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ze)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_ZHE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Cyrillic_zhe)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(dagger)]
                 '(lambda () (interactive) (insert "+")))
 (global-set-key [(degree)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(doublelowquotemark)]
                 '(lambda () (interactive) (insert "\"")))
 (global-set-key [(ellipsis)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(emdash)]
                 '(lambda () (interactive) (insert "-")))
 (global-set-key [(endash)]
                 '(lambda () (interactive) (insert "-")))
 (global-set-key [(EuroSign)]
                 '(lambda () (interactive) (insert "E")))
 (global-set-key [(guillemotleft)]
                 '(lambda () (interactive) (insert "<")))
 (global-set-key [(guillemotright)]
                 '(lambda () (interactive) (insert ">")))
 (global-set-key [(leftdoublequotemark)]
                 '(lambda () (interactive) (insert "\"")))
 (global-set-key [(leftsinglequotemark)]
                 '(lambda () (interactive) (insert "\'")))
 (global-set-key [(Macedonia_dse)]
                 '(lambda () (interactive) (insert "s")))
 (global-set-key [(Macedonia_DSE)]
                 '(lambda () (interactive) (insert "S")))
 (global-set-key [(Macedonia_gje)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_GJE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Macedonia_kje)]
                 '(lambda () (interactive) (insert "k")))
 (global-set-key [(Macedonia_KJE)]
                 '(lambda () (interactive) (insert "K")))
 (global-set-key [(mu)]
                 '(lambda () (interactive) (insert "u")))
 (global-set-key [(nobreakspace)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(notsign)]
                 '(lambda () (interactive) (insert "~")))
 (global-set-key [(numerosign)]
                 '(lambda () (interactive) (insert "N")))
 (global-set-key [(periodcentered)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(registered)]
                 '(lambda () (interactive) (insert "R")))
 (global-set-key [(rightdoublequotemark)]
                 '(lambda () (interactive) (insert "\"")))
 (global-set-key [(rightsinglequotemark)]
                 '(lambda () (interactive) (insert "\'")))
 (global-set-key [(section)]
                 '(lambda () (interactive) (insert "#")))
 (global-set-key [(Serbian_dje)]
                 '(lambda () (interactive) (insert "d")))
 (global-set-key [(Serbian_DJE)]
                 '(lambda () (interactive) (insert "D")))
 (global-set-key [(Serbian_tshe)]
                 '(lambda () (interactive) (insert "h")))
 (global-set-key [(Serbian_TSHE)]
                 '(lambda () (interactive) (insert "h")))
 (global-set-key [(singlelowquotemark)]
                 '(lambda () (interactive) (insert "\'")))
 (global-set-key [(Ukrainian_GHEUP)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_gheup)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_I)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_i)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_IE)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_ie)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_YI)]
                 '(lambda () (interactive) (insert "�")))
 (global-set-key [(Ukrainian_yi)]
                 '(lambda () (interactive) (insert "�")))
EOF
}

print " )\n";
