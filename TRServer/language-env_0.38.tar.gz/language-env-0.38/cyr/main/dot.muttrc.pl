print "# Aliases for broken MUAs\n";
print "charset-hook windows-1250 CP1250\n";
print "charset-hook windows-1251 CP1251\n";
print "charset-hook US-ASCII     ${MAIL_ENCODING}\n";
print "charset-hook ISO-8859-1     ${MAIL_ENCODING}\n";
if ($CYR_ENC eq "UTF-8") {
    print "# The character set of the user.\n";
    print "set charset=utf-8\n";
}
if ($CYR_ENC eq "CP1251") {
    print "# The character set of the user.\n";
    print "set charset=windows-1251\n";
}
if ($CYR_ENC eq "ISO8859-5") {
    print "# The character set of the user.\n";
    print "set charset=iso-8859-5\n";
}
if ($CYR_ENC eq "KOI8-R") {
    print "# The character set of the user.\n";
    print "set charset=koi8-r\n";
}
if ($CYR_ENC eq "KOI8-U") {
    print "# The character set of the user.\n";
    print "set charset=koi8-u\n";
}
if ($CYR_ENC eq "ISO8859-2") {
    print "# The character set of the user.\n";
    print "set charset=iso-8859-2\n";
}
print "# The standard encoding for mails.\n";
print "set send_charset=\"$MUTT_ENCODING\"\n";
print "# Don't send mails quoted-printable\n";
print "set allow_8bit=yes\n";
