
print "# Setup the locale\n";
print "unset LC_ALL\n";
print "LANG=${LOCALE}\n";
print "LANGUAGE=${LANGUAGE_PO}\n";
print "PATH=${MAINDIR}/bin:" . '${PATH}' . "\n";
print "export LANG\n";
print "export LANGUAGE\n";
print "export PATH\n\n";

if ( $CYR_ENC eq "ISO8859-2" ) {
    print <<'EOF';
# Setup the console font and keyboard
case `tty` in
/dev/tty[0-9]*|/dev/vc/*) 
    if which consolechars >/dev/null 2>&1; then
        consolechars -f lat2-16
        consolechars --sfm iso02
        consolechars --acm iso02
    else
        setfont lat2-16
        setfont -m trivial
    fi
    loadkeys sr >/dev/null 2>&1
    echo -e -n "\\033(K" > `tty`
    ;;
esac
EOF
} else {
    print <<'EOF';
# Setup Cyrillic on console
case `tty` in
/dev/tty[0-9]*|/dev/vc/*) 
    if which cyr >/dev/null 2>&1; then
	cyr
    fi
    ;;
esac
EOF
}
