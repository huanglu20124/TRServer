print <<"EOF";
style ibm
size 16
layout ${CYR_KBD}
options ${CYR_OPTION}
EOF
if ($CYR_ENC eq "UTF-8") {
    print "encoding utf-8\n";
}
if ($CYR_ENC eq "CP1251") {
    print "encoding cp1251\n";
}
if ($CYR_ENC eq "ISO8859-5") {
    print "encoding iso-8859-5\n";
}
if ($CYR_ENC eq "KOI8-R") {
    print "encoding koi8-r\n";
}
if ($CYR_ENC eq "KOI8-U") {
    print "encoding koi8-u\n";
}
if ($CYR_ENC eq "ISO8859-2") {
    print "encoding iso-8859-5\n";
}
