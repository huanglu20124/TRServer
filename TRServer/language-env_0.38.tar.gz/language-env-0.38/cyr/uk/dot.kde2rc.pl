#xs comment -*-coding: iso-8859-5;-*-
Use Ukrainian locale and keyboard in KDE+gdm.
END
Use Ukrainian locale and keyboard in KDE+gdm.
END
