#   comment -*-coding: iso-8859-5;-*-
Setup RUSCII encoding in the X version of DosEmu.
END
Setup RUSCII encoding in the X version of DosEmu.
END
