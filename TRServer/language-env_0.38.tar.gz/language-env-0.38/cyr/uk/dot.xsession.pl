#xs comment -*-coding: iso-8859-5;-*-
Use Ukrainian locale and keyboard in X Window.
END
Use Ukrainian locale and keyboard in X Window.
END
