#   comment -*-coding: iso-8859-5;-*-
The program `cyr' can be used to setup Cyrillic on console.
This is its configuration file.
END
The program `cyr' can be used to setup Cyrillic on console.
This is its configuration file.
END
