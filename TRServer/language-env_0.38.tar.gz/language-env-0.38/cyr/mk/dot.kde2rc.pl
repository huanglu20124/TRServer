#xs comment -*-coding: iso-8859-5;-*-
Use Macedonian locale and keyboard in KDE+gdm.
END
Use Macedonian locale and keyboard in KDE+gdm.
END
