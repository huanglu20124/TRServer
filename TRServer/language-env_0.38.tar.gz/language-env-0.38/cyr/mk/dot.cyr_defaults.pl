#   comment -*-coding: iso-8859-5;-*-
The program `cyr' is used to setup Cyrillic on console.  Your keyboard
preferences will be recorded in this file.
END
The program `cyr' is used to setup Cyrillic on console.  Your keyboard
preferences will be recorded in this file.
END
