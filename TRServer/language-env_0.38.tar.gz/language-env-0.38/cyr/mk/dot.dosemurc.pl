#   comment -*-coding: iso-8859-5;-*-
Setup CP855 encoding in the X version of DosEmu.
END
Setup CP855 encoding in the X version of DosEmu.
END
