#xs comment -*-coding: iso-8859-5;-*-
Use Macedonian locale and keyboard in X Window.
END
Use Macedonian locale and keyboard in X Window.
END
