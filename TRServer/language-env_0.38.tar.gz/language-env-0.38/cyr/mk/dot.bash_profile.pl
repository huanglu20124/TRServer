# s comment -*-coding: iso-8859-5;-*-
This file is executed by bash(1) for login shells.
Setup the Macedonian locale and Cyrillic on console.
END
This file is executed by bash(1) for login shells.
Setup the Macedonian locale and Cyrillic on console.
END
