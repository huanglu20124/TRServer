#   comment -*-coding: iso-8859-5;-*-
Say to the mail user agent pine what is your encoding.
END
Say to the mail user agent pine what is your encoding.
END
