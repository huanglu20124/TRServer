! s comment -*-coding: iso-8859-5;-*-
Setting for some programs in X Window System.
END
Setting for some programs in X Window System.
END
