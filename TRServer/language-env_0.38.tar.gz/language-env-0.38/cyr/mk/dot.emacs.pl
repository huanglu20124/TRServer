;   comment -*-coding: iso-8859-5;-*-
Cyrillic for GNU Emacs and XEmacs.
END
Cyrillic for GNU Emacs and XEmacs.
END
