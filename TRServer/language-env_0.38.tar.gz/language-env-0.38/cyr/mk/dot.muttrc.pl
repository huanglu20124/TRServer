#   comment -*-coding: iso-8859-5;-*-
Say to the mail user agent mutt what is your encoding.
END
Say to the mail user agent mutt what is your encoding.
END
