#xs comment -*-coding: iso-8859-5;-*-
Use Macedonian locale and keyboard and Cyrillic fonts in X Window.
This setting is not needed for Debian.
END
Use Macedonian locale and keyboard and Cyrillic fonts in X Window.
This setting is not needed for Debian.
END
