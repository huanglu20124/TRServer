# s comment -*-coding: iso-8859-5;-*-
Cyrillic localization.  This setting is for Mandrake Linux only.
END
Cyrillic localization.  This setting is for Mandrake Linux only.
END
