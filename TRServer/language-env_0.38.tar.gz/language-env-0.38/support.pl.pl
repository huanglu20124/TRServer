# !Polski,Polish! -*-coding: iso-8859-2;-*-
#
# Polish support by Robert Luberda <robert@pingu.ii.uj.edu.pl>, Jul 2001

# ---------------------------------------------------
sub isNC($$$)
{
	my $reply;
        print STDERR "\n �� �� �� �� �� �� �� �� ��\n";
        print STDERR "Czy widzisz polskie znaki w linii powyzej? [t/N] ";
        $reply = <>;
        if ($reply =~ /t|T/) {
                return 1;
        }
        return 0;

}

# ---------------------------------------------------
sub initialize()
{
	&Sub::addlist("locales");
	&Sub::addlist("fonty");

# manpages
	&Sub::addlist("manpages-pl");
	if (&Sub::isinstalled("manpages-dev")) {
		&Sub::addlist("manpages-pl-dev");
	}

# linux-doc
	if (&Sub::isinstalled("doc-linux-html")) {
		&Sub::addlist("doc-linux-html-pl");
	}
	if (&Sub::isinstalled("doc-linux-text")) {
		&Sub::addlist("doc-linux-text-pl");
	}

# x-fonts
	if (&Sub::isinstalled("xserver-.*")) {
		&Sub::addlist("xfonts-biznet-iso-8859-2-base");
		&Sub::addlist("xfonts-biznet-iso-8859-2-75dpi");
		&Sub::addlist("xfonts-biznet-iso-8859-2-100dpi");
	}
 
	
	return 0;
}


# ---------------------------------------------------
sub sourceset2displayset ($)
{
	return $_[0];
}


# ---------------------------------------------------
sub analcode($)
{
	return 0;
}


# ---------------------------------------------------
sub convcode($$)
{
	return $_[0];
}


# ---------------------------------------------------
%messages = (

# msgid
  "\nPush [Enter] key to End.\n" =>
# msgstr1 (in native language but in ASCII)
  "\nNacisnij [Enter], aby zakonczyc.\n\000".
# msgstr2 (in native language and in native character set: for
# example ISO-8859-1)
  "\nNaci�nij [Enter], aby zako�czy�.\n" ,

# msgid
  "Now obtaining package list...\n" =>
  "Trwa pobieranie listy pakietow...\n\000".
  "Trwa pobieranie listy pakiet�w...\n" ,

# msgid
  "Do setting? " =>
  "Ustawic? \000".
  "Ustawi�? " ,

# msgid
  "Setting is not done.\n" =>
  "Nie ustawiono.\n\000".
  "Nie ustawiono.\n" ,

# msgid
  "Do setting...\n" =>
  "Zapisywanie ustawienia...\n\000".
  "Zapisywanie ustawienia...\n" ,

# msgid
  "Cannot read \"%s\".\n" =>
  "Nie mozna czytac \"%s\".\n\000".
  "Nie mo�na czyta� \"%s\".\n" ,

# msgid
  "Making a new file \"%s\"...\n" =>
  "Tworzenie nowego pliku \"%s\"...\n\000".
  "Tworzenie nowego pliku \"%s\"...\n" ,

# msgid
  "Cannot open \"%s\".\n" =>
  "Nie mozna otworzyc \"%s\".\n\000".
  "Nie mo�na otworzy� \"%s\".\n" ,

# msgid
  "Cannot write to \"%s\".\n" =>
  "Nie mozna zapisywac do \"%s\".\n\000".
  "Nie mo�na zapisywa� do \"%s\".\n" ,

# msgid
  "Cannot lock \"%s\".\n" =>
  "Nie mozna zablokowac \"%s\".\n\000".
  "Nie mo�na zablokowa� \"%s\".\n" ,

# msgid
  "Cannot close \"%s\".\n" =>
  "Nie mozna zamknac \"%s\".\n\000".
  "Nie mo�na zamkn�� \"%s\".\n" ,

# msgid
  "Install the following packages.\n" =>
# msgstr1 (ASCII)
  "Prosze zainstalowac nastepujace pakiety.\n\000".
# msgstr2 (in Native Character Set)
  "Prosz� zainstalowa� nast�puj�ce pakiety.\n" ,

# msgid
  "   Setting is now done.  To activate these settings,\n".
  "logout and login.\n".
  "   Read each dotfile and confirm the modification.\n".
  "If you don't like the setting, modify directly or\n".
  "add overriding setting after 'language-env end' line.\n".
  "   Read /usr/share/doc/language-env/README.* for detail.\n" =>
# msgstr1 (ASCII)
  "   Zapisano ustawienia.  Aby je uaktywnic, nalezy sie\n".
  "wylogowac i zalogowac ponownie\n.\n".
  "   Prosze przejrzec kazdy zmieniony plik konfiguracyjny i sprawdzic\n".
  "ustawienia. Jezeli nie sa one zgodne z Twoimi oczekiwaniami, \n".
  "popraw je lub dodaj wlasne nadpisujace ustawienie po linii 'language-env end'.\n".
  "   Szczegolowe informacje mozna znalezc w /usr/share/doc/language-env/README.* .\n\000" .
# msgstr2 (in Native Character Set)
  "   Zapisano ustawienia.  Aby je uaktywni�, nale�y si�\n".
  "wylogowa� i zalogowa� ponownie\n.\n".
  "   Prosz� przejrze� ka�dy zmieniony plik konfiguracyjny i sprawdzi�\n".
  "ustawienia. Je�eli nie s� one zgodne z Twoimi oczekiwaniami, \n".
  "popraw je lub dodaj w�asne nadpisuj�ce ustawienie po linii 'language-env end'.\n".
  "   Szczeg�owe informacje mo�na znale�� w /usr/share/doc/language-env/README.* .\n" ,

# msgid
  "Usage: set-language-env [options]\n".
  "  -l language : Specify language (otherwise choose from menu)\n".
  "  -h          : This help message\n".
  "  -v          : 'verbose mode'\n".
  "  -s          : Display list of supported languages and exit\n".
  "  -r          : Remove all settings\n".
  "  -N          : Never fork another set-language-env (for internal use)\n".
  "  -c          : Don't use native character set (for internal use)\n".
  "  -C          : Use native character set (for internal use)\n".
  "  -E          : Setting for /etc/skel directory (root user only)\n" =>
# msgstr1 (ASCII)
  "Uzycie: set-language-env [opcje]\n".
  "  -l jezyk    : Okresla jezyk (jezeli nie podano, to wybor z menu)\n".
  "  -h          : Ten komunikat pomocy\n".
  "  -v          : Tryb gadatliwy\n".
  "  -s          : Wyswietla liste wspieranych jezykow i konczy dzialanie\n".
  "  -r          : Usuwa wszystkie ustawienia\n".
  "  -N          : Nie forkuje set-language-env (do uzytku wewnetrznego)\n".
  "  -c          : Nie uzywa natywnego zestawu znakow (do uzytku wewnetrz.)\n".
  "  -C          : Uzywa natywnego zestawu znakow (do uzytku wewnetrznego)\n".
  "  -E          : Ustawienia w katalogu /etc/skel (tylko uzytkownik root)\n\000" .
# msgstr2 (in Native Character Set)
  "U�ycie: set-language-env [opcje]\n".
  "  -l j�zyk    : Okre�la j�zyk (je�eli nie podano, to wyb�r z menu)\n".
  "  -h          : Ten komunikat pomocy\n".
  "  -v          : Tryb gadatliwy\n".
  "  -s          : Wy�wietla list� wspieranych j�zyk�w i ko�czy dzia�anie\n".
  "  -r          : Usuwa wszystkie ustawienia\n".
  "  -N          : Nie forkuje set-language-env (do u�ytku wewn�trznego)\n".
  "  -c          : Nie u�ywa natywnego zestawu znak�w (do u�ytku wewn�trz.)\n".
  "  -C          : U�ywa natywnego zestawu znak�w (do u�ytku wewn�trznego)\n".
  "  -E          : Ustawienia w katalogu /etc/skel (tylko u�ytkownik root)\n" ,

# msgid
  "Install the following locales.\n" =>
  "Prosze zainstalowac nastepujace definicje ustawien regionalnych.\n\000".
  "Prosz� zainstalowa� nast�puj�ce definicje ustawie� regionalnych.\n" ,

# msgid
  "(Edit /etc/locale.gen and invoke locale-gen)\n" =>
  "(Wyedytuj /etc/locale.gen, a nastepnie uruchom locale-gen)\n\000".
  "(Wyedytuj /etc/locale.gen, a nast�pnie uruchom locale-gen)\n" ,

# msgid
  "" =>
  "\000".
  ""

);

$yes_upper = "T";
$yes_lower = "t";
$no_upper  = "N";
$no_lower  = "n";
$need_locale = 'pl_PL.ISO-8859-2(pl_PL.ISO-8859-2 ISO-8859-2)';
