# !Francais,French! -*-coding: iso-8859-1;-*-
#
# ---------------------------------------------------
# isNC()
# ---------------------------------------------------
sub isNC($$$)
{
	return 0;
}

# ---------------------------------------------------
# initialize()
# ---------------------------------------------------
sub initialize()
{
	&Sub::addlist("locales");
	&Sub::addlist("manpages-fr");
	&Sub::addlist("doc-linux-fr");
	&Sub::addlist("doc-debian-fr");

	@locales = glob("/usr/lib/locale/fr*");
	$belgium     = grep($_ =~ /fr_BE/ , @locales);
	$canada      = grep($_ =~ /fr_CA/ , @locales);
	$switzerland = grep($_ =~ /fr_CH/ , @locales);
	$luxembourg  = grep($_ =~ /fr_LU/ , @locales);
	if ($belgium)        {$default = 2;}
	elsif ($canada)      {$default = 3;}
	elsif ($switzerland) {$default = 4;}
	elsif ($luxembourg)  {$default = 5;}
	else                 {$default = 1;}
	$choices = " 1. France\n 2. Belgium\n 3. Canada\n" .
		" 4. Switzerland\n 5. Luxembourg\n 6. others\n  ";
	$territory = &Sub::select(
		"Which country do you live in?\n" . $choices,
		"Which country do you live in?\n" . $choices,
		6, $default);
	if ($territory == 6) {
		$Sub::COUNTRY = &Sub::ask(
			"Input ISO3166 two-character code of your country ",
			"Input ISO3166 two-character code of your country ");
	} else {
		@country = ("FR", "BE", "CA", "CH", "LU");
		$Sub::COUNTRY = $country[$territory - 1];
	}

	$Sub::ISO885915 = &Sub::yesno(
		"Do you want to use ISO-8859-15 (euro sign) ?",
		"Do you want to use ISO-8859-15 (euro sign) ?");

	if ($Sub::ISO885915) {
		$Sub::LOCALE = "fr_" . $Sub::COUNTRY . "\@euro";
		$Lang::need_locale = "$Sub::LOCALE($Sub::LOCALE!ISO-8859-15)";
		foreach $i ("xfonts-base", "xfonts-100dpi", "xfonts-75dpi") {
			if (&Sub::isinstalled($i)) {
				&Sub::addlist($i . "-transcoded");
			}
		}
	} else {
		$Sub::LOCALE = "fr_" . $Sub::COUNTRY;
		$Lang::need_locale = "$Sub::LOCALE($Sub::LOCALE!ISO-8859-1)";
	}
	return 0;
}

# ---------------------------------------------------
# sourceset2displayset()
# ---------------------------------------------------
sub sourceset2displayset ($)
{
	return $_[0];
}

# ---------------------------------------------------
# analcode()
# ---------------------------------------------------
sub analcode($)
{
	return 0;
}

# ---------------------------------------------------
# convcode()
# ---------------------------------------------------
sub convcode($$)
{
	return $_[0];
}


# ---------------------------------------------------
# messages
# ---------------------------------------------------

%messages = (

# msgid
"\nPush [Enter] key to End.\n" =>
# msgstr (in ASCII)
"\nAppuyez sur [Entree] pour finir.\n\000" .
# msgstr (in native character set: for example ISO-8859-1)
"\nAppuyez sur [Entr�e] pour finir.\n" ,

"Now obtaining package list...\n" =>
"Construction de la liste des paquets...\n" ,

"Do setting? " =>
"Configurer ? " ,

"Setting is not done.\n" =>
"La configuration n'a pas ete effectuee.\n\000" .
"La configuration n'a pas �t� effectu�e.\n" ,

"Do setting...\n" =>
"Configuration en cours...\n" ,

"Cannot read \"%s\".\n" =>
"Impossible de lire \"%s\".\n" ,

"Making a new file \"%s\"...\n" =>
"Construction d'un nouveau fichier \"%s\"...\n" ,

"Cannot open \"%s\".\n" =>
"Impossible de lire \"%s\".\n" ,

"Cannot write to \"%s\".\n" =>
"Impossible d'ecrire dans \"%s\".\n\000" .
"Impossible d'�crire dans \"%s\".\n" ,

"Cannot lock \"%s\".\n" =>
"Impossible d'obtenir un verrou sur \"%s\".\n" ,

"Cannot close \"%s\".\n" =>
"Impossible de fermer \"%s\".\n" ,

"Install the following packages.\n" =>
"Installez les paquets suivants.\n" ,

"(Edit /etc/locale.gen and invoke locale-gen)\n" =>
"(Edit /etc/locale.gen and invoke locale-gen)\n",

"   Setting is now done.  To activate these settings,\n".
"logout and login.\n".
"   Read each dotfile and confirm the modification.\n".
"If you don't like the setting, modify directly or\n".
"add overriding setting after 'language-env end' line.\n".
"   Read /usr/share/doc/language-env/README.* for detail.\n" =>
# msgstr (in ASCII)
"   La configuration est terminee. Les changements seront effectifs\n".
"au prochain login.\n".
"   Verifiez chaque fichier de configuration et confirmez les modifications.\n".
"Si les preferences ne vous conviennent pas, modifiez-les directement ou\n".
"ajoutez de nouvelles preferences apres la ligne 'language-env end'.\n".
"   Consultez /usr/share/doc/language-env/README.* pour plus de details.\n\000".
# msgstr (in native character set: for example ISO-8859-1)
"   La configuration est termin�e. Les changements seront effectifs\n".
"au prochain login.\n".
"   V�rifiez chaque fichier de configuration et confirmez les modifications.\n".
"Si les pr�f�rences ne vous conviennent pas, modifiez-les directement ou\n".
"ajoutez de nouvelles pr�f�rences apr�s la ligne 'language-env end'.\n".
"   Consultez /usr/share/doc/language-env/README.* pour plus de d�tails.\n",

"Usage: set-language-env [options]\n".
"  -l language : Specify language (otherwise choose from menu)\n".
"  -h          : This help message\n".
"  -v          : 'verbose mode'\n".
"  -s          : Display list of supported languages and exit\n".
"  -r          : Remove all settings\n".
"  -N          : Never fork another set-language-env (for internal use)\n".
"  -c          : Don't use native character set (for internal use)\n".
"  -C          : Use native character set (for internal use)\n".
"  -E          : Setting for /etc/skel directory (root user only)\n" =>
"Usage: set-language-env [options]\n".
"  -l langue   : Precisez la langue (selectionnee sinon dans le menu)\n".
"  -h          : Ce message d'aide\n".
"  -v          : Mode 'bavard'\n".
"  -s          : Affiche la liste des langues possibles et quitte\n".
"  -r          : Supprimer les preferences actuelles\n" .
"  -N          : Ne pas dupliquer \"set-language-env\" (usage interne)\n".
"  -c          : Ne pas utiliser le jeu de caracteres natifs (usage interne)\n".
"  -C          : Utiliser le jeu de caracteres natifs (usage interne)\n".
"  -E          : Modifier les preferences dans /etc/skel (root seulement)\n\000".
"Usage: set-language-env [options]\n".
"  -l langue   : Pr�cisez la langue (s�lectionn�e sinon dans le menu)\n".
"  -h          : Ce message d'aide\n".
"  -v          : Mode 'bavard'\n".
"  -s          : Affiche la liste des langues possibles et quitte\n".
"  -r          : Supprimer les pr�f�rences actuelles\n" .
"  -N          : Ne pas dupliquer \"set-language-env\" (usage interne)\n".
"  -c          : Ne pas utiliser le jeu de caract�res natifs (usage interne)\n".
"  -C          : Utiliser le jeu de caract�res natifs (usage interne)\n".
"  -E          : Modifier les pr�f�rences dans /etc/skel (root seulement)\n",

# msgid
"Install the following locales.\n" =>
# msgstr1 (ASCII)
"Installation des locales suivantes.\n\000".
# msgstr2 (in Native Character Set)
"Installation des locales suivantes.\n" ,

# msgid
"(Edit /etc/locale.gen and invoke locale-gen)\n" =>
# msgstr1 (ASCII)
"(Editez /etc/locale.gen et lancez locale-gen)\n\000".
# msgstr2 (in Native Character Set)
"(Editez /etc/locale.gen et lancez locale-gen)\n" ,

# msgid
"" =>
# msgstr1 (ASCII)
"\000".
# msgstr2 (in Native Character Set)
""

);

# ---------------------------------------------------
# yes and no
# ---------------------------------------------------
$yes_upper = "O";
$yes_lower = "o";
$no_upper = "N";
$no_lower = "n";

# ---------------------------------------------------
# This variable shows the needed locale.  This is
# introduced since language-env 0.12 because locales
# package stopped to supply precompiled locale data
# since locales 2.2-1.
#
# The check is done by whether the directory of
# /usr/lib/locales/$needlocale exists or not.
#
# Multiple locales can be specified with delimiter
# of space code.
# ---------------------------------------------------
#
# This variable is set by initialize().
# $need_locale = 'fr_FR fr_FR@euro';
