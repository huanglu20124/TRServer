! s comment -*-coding: iso-8859-5;-*-
Setting for some programs in X Window System.
END
Setting for some programs in X Window System.
END
print <<"EOF";
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! Emacs
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Emacs.font:                     -*-courier-medium-r-*--14-*-*-*-*-*-${FONTSET}
Emacs*menubar*Font:             -*-helvetica-bold-r-*--16-*-*-*-*-*-${FONTSET}
Emacs*menubar*background:       grey
Emacs*menubar*foreground:       grey30
Emacs.background:               lightgray
Emacs.foreground:               black
Emacs.cursorColor:              red
Emacs.bitmapIcon:               on

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! A4 paper
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Ghostview.pageMedia:            A4
XDvi.paper:                     A4

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! Xman
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Xman*manualFontBold:                -*-courier-bold-r-*-*-*-120-*-*-*-*-${FONTSET}
Xman*manualFontItalic:              -*-courier-medium-o-*-*-*-120-*-*-*-*-${FONTSET}
Xman*manualFontNormal:              -*-courier-medium-r-*-*-*-120-*-*-*-*-${FONTSET}
Xman*manualFontSymbol:              -*-symbol-*-*-*-*-*-120-*-*-*-*-*-*
!Xman*directoryFontNormal:          -*-courier-medium-r-*-*-*-120-*-*-*-*-${FONTSET}
Xman*directoryFontNormal:           -*-helvetica-medium-r-*-*-*-120-*-*-*-*-${FONTSET}
!Xman*directoryFontNormal:          -*-serene-bold-r-*-*-*-120-*-*-*-*-${FONTSET}

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! XTerm
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
XTerm*VT100*font:            ${SHORTFONTSET}-fixed
XTerm*VT100*font1:           ${SHORTFONTSET}-nil2
XTerm*VT100*font2:           ${SHORTFONTSET}-5x7
XTerm*VT100*font3:           ${SHORTFONTSET}-6x10
XTerm*VT100*font4:           ${SHORTFONTSET}-7x13
XTerm*VT100*font5:           ${SHORTFONTSET}-9x15
XTerm*VT100*font6:           ${SHORTFONTSET}-10x20
XTerm*tek4014*fontLarge:     ${SHORTFONTSET}-9x15
XTerm*tek4014*font2:         ${SHORTFONTSET}-8x13
XTerm*tek4014*font3:         ${SHORTFONTSET}-6x13
XTerm*tek4014*fontSmall:     ${SHORTFONTSET}-6x10

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! Rxvt
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Rxvt*font:                   ${SHORTFONTSET}-7x14
Rxvt*font1:                  ${SHORTFONTSET}-6x10
Rxvt*font2:                  ${SHORTFONTSET}-6x13
Rxvt*font3:                  ${SHORTFONTSET}-8x13
Rxvt*font4:                  ${SHORTFONTSET}-9x15

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! xclipboard
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
XClipboard*Command*Font:	-*-helvetica-bold-r-normal--*-120-*-*-*-*-${FONTSET}
XClipboard*Label*Font:		-*-helvetica-bold-r-normal--*-120-*-*-*-*-${FONTSET}
XClipboard*Text*Font:		-*-courier-medium-r-normal--*-120-*-*-*-*-${FONTSET}

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! xditviev
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Xditviev*MenuButton*Font:	-*-helvetica-bold-r-normal--*-120-*-*-*-*-${FONTSET}
Xditviev*SimpleMenu*Font:	-*-helvetica-bold-r-normal--*-120-*-*-*-*-${FONTSET}
Xditviev*Text*Font:		-*-courier-medium-r-normal--*-120-*-*-*-*-${FONTSET}
EOF
