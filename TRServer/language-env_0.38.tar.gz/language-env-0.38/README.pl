O language-env
==============

language-env jest pakietem u�atwiaj�cym konstruowanie �rodowiska
j�zyka natywnego poprzez tworznie lub modyfikowanie plik�w konfiguracyjnych
(tzw. "dot-files"). Ka�dy u�ytkownik powinien utworzy� swoje �rodowisko
przez wywo�anie polecenia set-language-env.

"Dot-files" oznacza pliki umieszczone w katalogu domowym u�ytkownika,
kt�rych nazwy zaczynaj� si� od kropki.

Uruchomienie polecenia set-language-env dodaje do plik�w konfiguracyjnych
r�ne ustawienia natywnego j�zyka otoczone liniamu "---- language-env".
Ustawienia te s� dodawane do istniej�cych plik�w, kiedy set-language-env
zosta� uruchomiony po raz pierwszy. U�ytkownik mo�e dodawa� linie przed
lub za liniami dodanymi przez program - i modyfikacje te zostan�
zachowane po nast�pnym uruchomieniu set-language-env. Mo�na r�wnie�
zmienia� linie wygenerowane przez program, jednak�e nast�pne uruchomienie
set-language-env spowoduje ich nadpisanie.
Prosimy o niemodyfikowanie linii "---- language-env".


Kontakt
=======

Autor programu:
 Tomohiro KUBOTA <kubota@debian.org> 
 http://www.debian.or.jp/~kubota/linuxwork/language-env.html

Obs�uga polskiej wersji:
 Robert Luberda <robert@debian.org> 


Prawa autorskie
===============

Zobacz /usr/share/doc/language-env/copyright.

---
Robert Luberda <robert@pingu.ii.uj.edu.pl>  Wed, 11 Jul 2001
